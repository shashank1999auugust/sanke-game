 export const data=[
    { id:1,
      question:"question 1",
      answer:"answer 1"
    },
    {
        id:2,
     question:"question 2",
      answer:"answer 2"
    }
]