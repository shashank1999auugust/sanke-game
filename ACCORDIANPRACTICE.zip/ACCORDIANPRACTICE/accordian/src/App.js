
import './App.css';
import {useState} from "react"
import { data } from './data';
function App() {

  const [selected, setSelected]= useState(null)
  function showornot(currentid){
  setSelected(currentid===selected?null: currentid)
  }
  return (
    <div className="App">
       {
        data.map((dataitem)=>{
          return(
            <div key={dataitem.id}>
               <div  className="Questions" onClick={()=>showornot(dataitem.id)}> 
                <h3>{dataitem.question}</h3>
               </div>
                {
              selected===dataitem.id?
              <div className="Questions">{dataitem.answer}</div>
              :null
             }
            </div>
  
          )
        })
        
       }
    </div>
  );
}

export default App;




// import './App.css';
// import {useState} from "react"
// import { data } from './data';
// function App() {
//   const [activeTab, setActiveTab] = useState(0);

//   const tabs = [
//     {
//       title: 'Tab 1',
//       content: 'This is the content of Tab 1.'
//     },
//     {
//       title: 'Tab 2',
//       content: 'This is the content of Tab 2.'
//     },
//     {
//       title: 'Tab 3',
//       content: 'This is the content of Tab 3.'
//     }
//   ];

//   const handleTabClick = (index) => {
//     setActiveTab(index);
//   };

//   return (
//     <div>
//       <div className="tabs">
//         {tabs.map((tab, index) => (
//           <button
//             key={index}
//             className={activeTab === index ? 'active' : ''}
//             onClick={() => handleTabClick(index)}
//           >
//             {tab.title}
//           </button>
//         ))}
//       </div>
//       <div className="tab-content">
//         {tabs[activeTab].content}
//       </div>
//     </div>
//   );
  
 
// }

// export default App;


// App.js
// import Popup from './Popup';

// const App = () => {
//   return (
//     <div>
//       <Popup />
//     </div>
//   );
// };

// export default App;



