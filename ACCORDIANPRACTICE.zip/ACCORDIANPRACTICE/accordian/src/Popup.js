// Popup.js
import React, { useState } from 'react';

const Popup = () => {
  const [isOpen, setIsOpen] = useState(false);

  const handleOpen = () => {
    setIsOpen(true);
  };

  const handleClose = () => {
    setIsOpen(false);
  };

  return (
    <div>
      <button onClick={handleOpen}>Open Popup</button>
      {isOpen && (
        <div className="popup-overlay">
          <div className="popup-content">
            <button className="close-button" onClick={handleClose}>
              Close
            </button>
            <h2>This is a Popup</h2>
            <p>You can put any content inside the popup.</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default Popup;