
import './App.css';
import QRCODEGEN from './qrCodeGenerator';
function App() {
  return (
    <div className="App">
      <QRCODEGEN/>
    </div>
  );
}

export default App;
