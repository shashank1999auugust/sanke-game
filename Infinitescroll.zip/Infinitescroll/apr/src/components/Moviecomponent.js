import React from 'react'
import Moviecard from "./Moviecard"

const Moviecomponent = ({movieinfo}) => {
  return (
    <div>
      {movieinfo.map((currVal,id)=>{
       return<Moviecard key={id} mydata={currVal}/>
      })}
    </div>
  )
}

export default Moviecomponent
