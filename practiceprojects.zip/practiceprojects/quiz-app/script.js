const container= document.querySelector(".container")
const questionBox= document.querySelector(".question")
const choicesBox= document.querySelector(".choices")
const nextbtn= document.querySelector(".nextBtn")
const scoreCard= document.querySelector(".scoreCard")


const quiz=[
    {
        question: "Q. Which of the following is not a CSS box model property?",
        choices: ["margin", "padding", "border-radius", "border-collapse"],
        answer: "border-collapse"
    },
    {
        question: "Q. Which of the following is not a valid way to declare a function in JavaScript?",
        choices: ["function myFunction() {}", " let myFunction = function() {};", "myFunction: function() {}", "const myFunction = () => {};"],
        answer: "myFunction: function() {}"
    },
    {
        question: "Q. Which of the following is not a JavaScript data type?",
        choices: ["string", "boolean", "object", "float"],
        answer: "float"
    },
    {
        question: "Q. What is the purpose of the this keyword in JavaScript?",
        choices: ["It refers to the current function.", "It refers to the current object.", "It refers to the parent object.", " It is used for comments."],
        answer: "It refers to the current object."
    }
]

let currentQuestionIndex=0;
let score=0;
let quizover=false;
//function to show questions 
const showQuestions=()=>{
const questionDetails=quiz[currentQuestionIndex];
// console.log(questionDetails)
questionBox.textContent=questionDetails.question

choicesBox.textContent=""
for(let i=0; i<questionDetails.choices.length; i++){
    const currentChoice=questionDetails.choices[i];
    const choicediv= document.createElement("div");
    choicediv.textContent=currentChoice;
    choicediv.classList.add("choice")
    choicesBox.appendChild(choicediv);

    choicediv.addEventListener("click",()=>{
        if(choicediv.classList.contains("selected")){
            choicediv.classList.remove("selected")
        }
        else{
            choicediv.classList.add("selected")
        }
    })
}

}

//function to check answers
const checkAnswer=()=>{
    const selectedChoice= document.querySelector(".choice.selected")
    // console.log(selectedChoice)
    if(selectedChoice.textContent=== quiz[currentQuestionIndex].answer){
        alert("correct answer")
        score++;
    }
    else{
        alert("wrong answer")
    }
    currentQuestionIndex++;
    if(currentQuestionIndex<quiz.length){
        showQuestions()
     }
     else{
        showScore()
        quizover=true
     }
}

//function to show score 
const showScore=()=>{
    questionBox.textContent=""
    choicesBox.textContent=""
    scoreCard.textContent= `You Score ${score} out of ${quiz.length}`
    nextbtn.textContent="Play Again"
}


showQuestions()

nextbtn.addEventListener("click", ()=>{
    const selectedChoice=document.querySelector(".choice.selected")
    if(!selectedChoice && nextbtn.textContent==="Next"){
        alert("select your answer")
        return
    }
    if(quizover){
            nextbtn.textContent="Next";
            scoreCard.textContent=""
            currentQuestionIndex=0;
            showQuestions();
            quizover=false
            score=0;
        }
    else{
        checkAnswer()
    }
    
})