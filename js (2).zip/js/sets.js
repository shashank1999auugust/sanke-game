// sets iterable hote history,,, unique elements  , order is not gurantee, no index based access

// we can write any iterable in set()
// const numbers=new Set([1,2,3,3,3,3,3]);
// // my out wil be (1,2,3) becuase no duplicates allowed
// console.log(numbers);

// // y index base access allow nhi h 
// console.log(numbers[2]);


// const yes= new Set("shashank");
// console.log(yes);

// -----------------------------------------------------------------------------------------------------

// const numbers=new Set();
// numbers.add(1);
// numbers.add(2);
// //aise add krenge agr to y add honge 2no becuase y duplicate nahi h y 2 different alg alg array h memory m
// numbers.add(["item1","item2"]);
// numbers.add(["item1","item2"]);

// console.log(numbers);



// const items=["item1","item2","item3"];

// const numbers=new Set();
// numbers.add(1);
// numbers.add(2);
// numbers.add(3);
// //aise add krenge agr to y 2 bar add nhi honge kuki y dulicate h same memory h items 1 hi arrray h 
// // square bracket m hum jb bhi likhte h to wo ek new memory m assign hota h 
// numbers.add(items);
// numbers.add(items);

// // pr aise ho jaenge add kuki square baracket h
// // numbers.add([items]);
// // numbers.add([items]);

// // to check whether something is present in set or not 
// console.log(numbers);
// if(numbers.has(1)){
//     console.log(" 1 is present");
// }
// else{
//     console.log("1 is notpresent");
// }


// -----------------------------------------------------------------------------------------------------
// to show that sets are iterables ..  use  for of loop
// yes they are iterable
// const items=["item1","item2","item3"];
// const numbers=new Set();
// numbers.add(1);
// numbers.add(2);
// numbers.add(3);
// numbers.add(4);
// numbers.add(5);
// numbers.add(6);
// numbers.add(items);

// for(let number of numbers){
//     console.log(number);
// }


// ----------------------------------------------------------------------------------------------------

const myarray=[1,2,4,4,5,6,5,6];
const uniqueelements=new Set(myarray);
// to calculate lenth of set 
let length=0;
for(let element of uniqueelements){
    length++;
}
console.log(uniqueelements);
console.log(length);