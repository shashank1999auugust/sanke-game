// used to create array with particular value 
// const myarray=new Array(10).fill(-10);
// console.log(myarray);


const myarray=[1,2,3,4,5,6,7,8];
// REQUIREMENT MAKE 3 4 5 TO 0
//  fill k arguments(value,start,end)
// 2 -- 3 ka index h   4 h 5 ka index burt (2,4) sirf 3 and 4 ko 0 bnaenge 5 ko nahi 
// kuki 4 tk index jaega 4th index ko fill nahi krega
// myarray.fill(0,2,4);
myarray.fill(0,2,5);
console.log(myarray);