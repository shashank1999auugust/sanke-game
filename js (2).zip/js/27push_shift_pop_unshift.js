let fruits=["apple", "mango", "grapes"]
// PUSH ADD ELEMNT IN LAST 
// console.log(fruits)
// fruits.push("banana")
// console.log(fruits)

//POP REMOVE ELEMENT FROM LAST 
// console.log(fruits)
// fruits.pop()
// console.log(fruits)

// Unshift  it push element in Start 
// console.log(fruits)
// fruits.unshift("banana")
// console.log(fruits)


//shift removes the elemet from the start

// console.log(fruits)
// fruits.shift()
// console.log(fruits)

// push and pop are fast because shift and unshift will first shift the all elements in memory 