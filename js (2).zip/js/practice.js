document.getElementById("btn").onclick=function(e){
    e.preventDefault()
    console.log("button clicked");
}

document.addEventListener("DOMContentLoaded",function(){
    alert("Hello ji")
})