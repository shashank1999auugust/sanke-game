//  Type of operator
// let age=22;
// let firstname= "shashank";
// console.log(typeof(age));
// console.log(typeof(firstname));


// convert no to string 
// add empty string after no.to convert it into string
// age= age + "";
// console.log(typeof(age));

// convert string to No
// let mystring="34";
// add + before string t convert it from string to no
// console.log(typeof (+mystring));


// another ways to convert
// let age=16;
// age=String(age);
// console.log( typeof age);

// let age="16";
// age=Number(age);
// console.log( typeof age);


