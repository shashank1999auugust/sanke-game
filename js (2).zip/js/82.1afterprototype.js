// must do all functioncreatesmultipleobject1,2,3,prototype.js 

// const usermethods={
//   about:function(){
//       return `${this.firstname} is ${this.age} years old`;
//   },
//     is18:function(){
//       return this.age>=18;
//   },
//   sing:function(){
// return "toon na la la laa la"
//   }
// }
 
// function createuser(firstname,lastname,email,age,address){
//   // const user={}; changes as per functioncreatemultipleobject3klieprerequisite.js
//   // is line s usermethods prototype m set ho jaenge
//   const user=Object.create(usermethods)
//   user.firstname=firstname;
//   user.lastname=lastname;
//   user.email=email;
//   user.age=age;
//   user.address=address;
  


  
//   return user;
//  }
//  const user1=createuser("harshit","vashist","harshit@gmail.com",3,"my address");
//  const user2=createuser("harsh","vashist","harshit@gmail.com",3,"my address");
//  const user3=createuser("mohit","vashist","harshit@gmail.com",3,"my address");

// //  console.log(user1);
// //    we are able to access because of  const user=Object.create(usermethods)
// //  console.log(user1.about());

// //  yha pr createuser ek function h to uska prototype bhi hoga lets check  haan mili h prototype property
// console.log(createuser.prototype);


// --------------------------------------------------------------------------------------------------
// ---------------------------------------------------------------------------------------------
// --------------------------------------------------------------------
// ab hum kya krenge  alg s usermethods nahi bnaenge .. ab hum prototype m add kr denge function k 

function createuser(firstname,lastname,email,age,address){
  // const user={}; changes as per functioncreatemultipleobject3klieprerequisite.js
  // is line s usermethods prototype m set ho jaenge
  //BASICALLY ISKA PROTO ISKE KHUD K PROTOYPE KO SET KR DIA
  const user=Object.create(createuser.prototype)
  user.firstname=firstname;
  user.lastname=lastname;
  user.email=email;
  user.age=age;
  user.address=address;
  return user;
 }

//  adding usermethods in prototype itself
createuser.prototype.about=function(){
  return `${this.firstname} is ${this.age} years old`;
};

createuser.prototype.is18=function(){
        return this.age>=18;
    };

createuser.prototype.sing=function(){
  return "toon na la la laa la";
    };

 const user1=createuser("harshit","vashist","harshit@gmail.com",3,"my address");
 const user2=createuser("harsh","vashist","harshit@gmail.com",13,"my address");
 const user3=createuser("mohit","vashist","harshit@gmail.com",19,"my address");


 console.log(user1);
 console.log(user1.about());
 console.log(user1.is18());