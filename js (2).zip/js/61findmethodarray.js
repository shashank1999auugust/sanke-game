//  FIND METHOTH : basically find yha pr humara first occurence FIND krega jaise
//  hi ise cat milega kuki uski length 3 h to use return kr dega 

// const myarray=["hello","cat","dog","lion"];
// function islength3(string){
//     return string.length===3;
// }
//  const ans=islength3("dog");
//  console.log(ans);


//   const ans=myarray.find(islength3);
//   console.log(ans);




// with arrow function inside find 
// const myarray=["hello","cat","dog","lion"];

//   const ans=myarray.find((string)=>{
//     return string.length===3;
//   });
//   console.log(ans);


const users=[
{userid:1, username:"harshit"},
{userid:2, username:"harsh"},
{userid:3, username:"nitish"},
{userid:4, username:"mohit"},
{userid:5, username:"aaditya"}
];
 const ans=users.find((user)=>{
    return user.userid===3;
});
console.log(ans);