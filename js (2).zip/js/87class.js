// Lets don the same code with class 
// classes are fake ,.. internally same aise hi kam hota h function createuser jaise 


class Createuser{
        constructor(firstname,lastname,email,age,address){
          console.log("constructor called");
            this.firstname=firstname;
            this.lastname=lastname;
            this.email=email;
            this.age=age;
            this.address=address; 
        }

        about(){
          return `${this.firstname} is ${this.age} years old`;
        }
        is18(){
          return this.age>=18;
        }
        sing(){
          return "toon na la la laa la";
        }
        func(a){
          console.log(a);
        }
}


       const user1= new Createuser("harshit","vashist","harshit@gmail.com",24,"my address");
      //  const user2= new Createuser("harsh","vashist","harshit@gmail.com",13,"my address");
      //  const user3= new Createuser("mohit","vashist","harshit@gmail.com",19,"my address");

      console.log(user1.firstname);
      console.log(user1.is18());
      console.log(Object.getPrototypeOf(user1));
      user1.func("harshit");

// ------------------------------------------------------------------------------------------
// ------------------------------------------------------------------------------------------

  // purani file ka code bina class k 
// function Createuser(firstname,lastname,email,age,address){
//         this.firstname=firstname;
//         this.lastname=lastname;
//         this.email=email;
//         this.age=age;
//         this.address=address;
//        }
      
//       //  adding usermethods in prototype itself
//       Createuser.prototype.about=function(){
//         return `${this.firstname} is ${this.age} years old`;
//       };
      
//       Createuser.prototype.is18=function(){
//               return this.age>=18;
//           };
      
//       Createuser.prototype.sing=function(){
//         return "toon na la la laa la";
//           };
//     //    use new keyword here 
//        const user1= new Createuser("harshit","vashist","harshit@gmail.com",3,"my address");
//        const user2= new Createuser("harsh","vashist","harshit@gmail.com",13,"my address");
//        const user3= new Createuser("mohit","vashist","harshit@gmail.com",19,"my address");
      