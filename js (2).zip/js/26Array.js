// intro to arrays
// refference type , mutable 
// ordered cllection of items 
let fruits=["apple","mango","grapes"]
let numbers=[1,2,3,4]
let mixed=[1,2,3.4,"string",null,undefined]
console.log(mixed)
console.log(fruits[2])

//mutable
numbers[2]=4
console.log(numbers)

//type of array is object , type of object is also object then how to confirm its array?
let obj= {}
console.log(typeof(fruits))
console.log(typeof(obj))

//confirm through array.isarray
console.log(Array.isArray(fruits))