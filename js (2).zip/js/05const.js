const pi=3.14;
// In const we can not change Value
// pi=3.15 ;
console.log(pi);
// but we can do like this 
// console.log(pi*2);
