// booleand and comparison operatior
// let num1=7;
// let num2=7;
// console.log(num1>=num2);

//  == vs ===

// let num1="7"
// let num2=7
// one is string second is Node. but it will give true beccause == check for value not check datatype
// console.log(num1==num2);

// if we use === then it will check for datatype also so this time it wll give false
// console.log(num1===num2);

// let num1=7
// let num2=7
//  it will give false  because as per this both no are  equal
// console.log(num1!=num2);

// let num1=7
// let num2=8
// it will give true as both are not equal
// console.log(num1!=num2);

// != vs !==
// let num1=7;
// let num2="7";
// these are different , ideally it should give true as they are not equal thwre data type is different
// but != not check data type so it says false
// console.log(num1!=num2);
// by this way it will check for data type also so now it will give true yes(TRUE) they are not equal
// console.log(num1!==num2);