// use const for creating array 
const fruits=["apple", "mango"]  //0x11
fruits.push("banana")
console.log(fruits)

// we check that banan is added , how ? it was const ..
// suppose heap memory is 0x11
// so we are not changing theaddress here address is same in push 
// but if we do something like this  then it will give error , assignment to constant 
fruits=["grapes"]

// usually use const for arrays 
// jb bhi koi refference type bnao to const use kro better h 