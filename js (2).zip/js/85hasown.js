function Createuser(firstname,lastname,email,age,address){
    
        this.firstname=firstname;
        this.lastname=lastname;
        this.email=email;
        this.age=age;
        this.address=address;
      
       }
      
      //  adding usermethods in prototype itself
      Createuser.prototype.about=function(){
        return `${this.firstname} is ${this.age} years old`;
      };
      
      Createuser.prototype.is18=function(){
              return this.age>=18;
          };
      
      Createuser.prototype.sing=function(){
        return "toon na la la laa la";
          };
  
       const user1= new Createuser("harshit","vashist","harshit@gmail.com",3,"my address");
       const user2= new Createuser("harsh","vashist","harshit@gmail.com",13,"my address");
       const user3= new Createuser("mohit","vashist","harshit@gmail.com",19,"my address");
      
      
      for(key in user1){
        // isse y prototype wali ko bhi key bta rha h 
        // console.log(key);
        // if we want to only check the keys of the function then do this 
       if( user1.hasOwnProperty(key)){
        console.log(key);
       }
      }