// const arr=["hi","hello"];
// const arr2=arr;
// we only pushed element in arr but when we print and check we see that in both its added 
// it is becuase heap memory .. and y reference hote h 
// arr.push("how");
// console.log(arr);
// console.log(arr2);


// so kaise kre .?
// const arr=["hi","hello"];
// aise ise spread operator khte h
// const arr2=[...arr];
// arr.push("how");
// console.log(arr);
// console.log(arr2);



// we can add more element in arr2 also 
// const arr=["hi","hello"];
// const arr2=[...arr , "why", "when"]
// console.log(arr2);


//2nd tarika

// let array1=["item1","item2"];
// let array2=array1;
//concat , isme hum khali array m array 1 jod rhe h 
// let array2=[].concat(array1);
// array1.push("item3");
// console.log(array1);
// console.log(array2);



// 3rd tarika 
// isme slice m kya hota h ki 0 index s leke last tk aajata h wo humne new array m day dia (in array 2)
let array1 = ["item1", "item2"];
// let array2=array1;
let array2 = array1.slice(0);
array1.push("itemdd3");
console.log(array1);
console.log(array2);
