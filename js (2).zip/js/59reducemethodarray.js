// const numbers=[1,2,3,4,5];
// const sum=numbers.reduce((accumulator,currentvalue)=>{
//     return accumulator+currentvalue;
// })
// console.log(sum);
// very first time accumulator =1    current value=2         return= 3
                          //    3                  3                  6
                          //    6                  4                  10
                          //    10                 5                  15



const usercart=[
    {productid:1,productname: "mobile",price:12000},
    {productid:2,productname: "laptop",price:22000},
    {productid:3,productname: "tv",price:15000}
]

// using for of loop sum 
let sum=0;
for(user of usercart){
sum+=user.price;
}
console.log(sum);



// using .reduce find sum 
// const totalamount=usercart.reduce((totalprice,currentproduct)=>{
//        return totalprice+currentproduct.price;
// },0)
// isme ,0 s hum  totalprice ki hum initial amount set kr rhe h 

// console.log(totalamount);