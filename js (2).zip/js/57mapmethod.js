const numbers=[3,4,6,1,8];
// const square=function(number){
//     return number*number;
// }
// it creates new array  and store in squareno
//  const squareno=numbers.map(square);
//  console.log(squareno);


// or we can write like this 
 const squareno=numbers.map((number)=>{
 return number*number
 })
 console.log(squareno)

//  _____________________________________________________________________


const users=[
    {firstname:"harshit", age:23},
    {firstname:"mohit", age:21},
    {firstname:"nitish", age:22},
    {firstname:"garima", age:20},  
]

const usernames=users.map((user)=>{
    return(user.firstname)
})
console.log(usernames)