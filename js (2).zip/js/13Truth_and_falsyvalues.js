// falsy values
// false
// ""
// null
// undefined
// 0
// for all above value of name all are false
// Example to check any one of above lets check for null
let name=null;
if(name){
 console.log(name)
}
else{
    console.log("name is empty ")
}

// truthy values abc , 1 -1 anything expect falsy values