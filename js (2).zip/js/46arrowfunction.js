//normal  function
// function iseven(num){
//     return num%2===0;
// }
// console.log(iseven(4));

// normal function with const //FUNCTION EXPRESSION
// const iseven= function(number){
// return number%2===0;
// }
// console.log(iseven(5));


//arrow function

// const iseven= (number)=>{
//     return number%2===0;
// }
// console.log(iseven(4));

// arrow more shorter version if we have one line only to return 

// const iseven= (number)=>  number%2===0;
// console.log(iseven(7));

