// function app(){
//     console.log("inside app");
// }
// app();

// const app=function(){
//     console.log("inside app");
// }
// app();


// we can see inside app function there are multiple functions 
const app=()=>{
    const myfun=()=>{
        console.log("hello from myfunc")
    }
    const addtwo=(num1,num2)=>{
        return num1+num2;
    }
    const mul=(num1,num2)=> num1*num2;
    console.log("inside app")
    myfun();
    console.log(addtwo(2,3));
}

app();