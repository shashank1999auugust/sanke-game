// iterables
// jisme hum for of loop lga ske 
// example string , array
const firstname="harshit";
for(let char of firstname){
    console.log(char);
}

const items=['item1','item2','item3'];
for(let item of items){
    console.log(item);
}

// can we do the same thing in object?
// const users={'key1':'value1','key2':'value2'};
// for(let user of users){
//     console.log(user);
// }
// so the answer is no 
// objects are not iterable


// array like object 
// jinke pas length property hoti h
// aur jisko hum index s access kr skte h
// example string
 const kyaname="harshit";
 console.log(kyaname.length);
 console.log(kyaname[0]);
