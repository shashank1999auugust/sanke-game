// y normal object ko hum object literals bhi khte h 
//isme keys humesha string m  hoti h ya fir symbol m
// const person={
//     firstname: "harshist",
//     age:23,
//     1:"one",
// }
// // with the below we can see taht it took 1 as a string
// console.log(person["1"]);
// for(let key in person){
//  console.log(typeof key)
// }

// console.log(person.firstname);
// console.log(person["firstname"]);

// -------------------------------------------------------------------------------------------------------

// const person= new Map();
// person.set('firstname','harshit')
// person.set('age',7)

// main difference between map and object is that in map key hum kisi bhi type ki rkh skte h 
// ex-
// person.set(1,'one');
// console.log(person);
// y hu m object m kr skte the map m nahi isse undefined aaega firstname access krne pr
// console.log(person.firstname);
// console.log(person["firstname"]);
// -------------------------------------------------------------------------
// to kya kre  by using get('') ethod we can access
// console.log(person.get('age'))

// sari keys print krne k lie .keys()
// console.log(person.keys());



// -----------------------------------------------------------------------
// map iterable h 
// for(let key of person.keys()){
//     console.log(key, typeof key);
// }


// for(let key of person){
//     console.log(key);
// }
// the above code will give three different array now how to destructure
// for(let [key,value] of person){
//     console.log(key,value);
// }

// ----------------------------------------------------------------------------------------------
// map bnate hue kaise define kre value? 
// const person= new Map([  ['firstname','harshit'],['age',7]  ])
// console.log(person);

// --------------------------------------------------------------------------------------
// y object h iski or infosmation store krni h mko but isme nahi khi or we can use map
const person1={
    id:1,
    firstname: "harshit",
}

// here key is perso1 which is object 
const userinfo= new Map();
userinfo.set(person1,{age:8,gender:"male"});

// id to normally mil jaegi
console.log(person1.id);
// delho ab hum kaise userinfo konaccess krte h jo humne person 1 k lie set kri h 
console.log(userinfo.get(person1).age);