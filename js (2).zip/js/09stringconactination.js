// string concatination
// let string1="shashank";
// let string2="sabharwal"
// let fullname= string1+ " "+string2;
// console.log(fullname);

// lets add them again but now first convert it nto number
let string1="10";
let string2="20"
// let fullname= +string1 + +string2;
// let fullname=Number(string1)+Number(string2)
console.log(fullname);