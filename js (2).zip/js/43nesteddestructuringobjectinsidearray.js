const users=[
    {userid:1, firstname:'harshit', gender:'male'},
    {userid:2, firstname:'mohit', gender:'male'},
    {userid:3, firstname:'nitish', gender:'MALE'}
]

// it will give whle individual objects in user 1 , user2, and user 3
// const[user1,user2,user3]=users;
// console.log(user1);

// THIS IS OBJECT DESTRUCTURING

// const[{firstname}, ,{gender}]=users;
// name of firstobject
// console.log(firstname);
// gender of 3rd object
// console.log(gender);


// name change of variables
const[{firstname:user1firstname}, ,{gender:user3gender}]=users;
// name of firstobject
console.log(user1firstname);
// gender of 3rd object
console.log(user3gender);