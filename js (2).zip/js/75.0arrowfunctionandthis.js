// Normal function when we do this so it takes from  user1 
// const user1={
//     firstname: "harshit",
//     age:8,
//     about: function(){
//         console.log(this.firstname, this.age);
//     }
// }
// user1.about();


// -------------------------------------------------------------------------------
// arrow function this takes from one level above and here one level above is window function 
// thats why undefined undefined 

const user1={
    firstname: "harshit",
    age:8,
    about: ()=>{
        console.log(this.firstname, this.age);
    }
}
user1.about();
// and isme hum change nahi kr skte iska this .call s  isme bhi undefined aaega
user1.about.call(user1);