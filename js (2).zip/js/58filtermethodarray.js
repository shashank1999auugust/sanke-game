//filter callbackfuncgtion must return true or false

const numbers=[1,3,2,6,4,8];

// const iseven=function(number){
//     return number%2==0;
// }

//  const evennumbers=numbers.filter(iseven);
// //  gives us new array with even numbers 
//  console.log(evennumbers);



//  now callback function directly define in  numbers.filter()  
const evennumbers=numbers.filter(function(number){
    return number%2==0;
})
  
//  gives us new array with even numbers 
 console.log(evennumbers);


 //  now callback function directly define in  numbers.filter()   but with arrow function
 
// const evennumbers=numbers.filter((number)=>{
//     return number%2==0;
// });
// //  gives us new array with even numbers 
//  console.log(evennumbers);