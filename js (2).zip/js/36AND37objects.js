key="email"
const person={
"name":"shashank",
"age":24,
"hobbies":["guitar","singing"]
}
// console.log(person);
console.log(person.age);

// add key value pair in person object by .
// person.gender="male";

// add key value pair in person by []
// person["gender"]="male";

// when [] is neccesary to input key value pair ? when key is a string with spaces
person["gender of mine is"]="male";
// with the help of [ we can print we cant do with . becuse key value is with spaces]
console.log(person["gender of mine is"]);

console.log(person);

// person[key]="abc@gmail.com"
// console.log(person);


// if we wrote like this  then instead of key name email , it will show key only
person.key="abc@gmail.com"
console.log(person);

