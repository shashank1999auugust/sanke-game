// const band={
//     bandname:"led zeppelin",
//     famoussong: "stairway to heaven",
//     year:1968,
//     anotherfamoussong: "kashmir"
// };
// let {bandname,famoussong}=band;
// console.log(bandname);

// const band={
//     bandname:"led zeppelin",
//     famoussong: "stairway to heaven",
//     year:1968,
//     anotherfamoussong: "kashmir"
// };
// we can change variable name 
// let {bandname:var1,famoussong}=band;
// this will give error becuse now name is changed to var1
// console.log(bandname);
// console.log(var1);


const band={
    bandname:"led zeppelin",
    famoussong: "stairway to heaven",
    year:1968,
    anotherfamoussong: "kashmir"
};
// suppose hume baki bache walo ka ek object bnana h  to use ...restProps
let {bandname,famoussong ,...restProps}=band;
console.log(restProps);
