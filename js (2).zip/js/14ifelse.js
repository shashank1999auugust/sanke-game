// if else condition 
let age=18;
if(age>18){
    console.log("user can play ddlc");
}
else{
    console.log("user can play mario");
}

