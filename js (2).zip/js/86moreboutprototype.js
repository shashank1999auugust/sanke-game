let numbers =[1,2,3];
// // internally javascript do like this 
// let numbers=new Array(1,2,3)
// // so basically jo upr line like h  Array(1,2,3)is function k  prototype m array k sare function hote h
// // numbers.  krke dekho
//array ka prototype array h
console.log(Object.getPrototypeOf(numbers));
// console.log(numbers);


// // array ka prototype check krenge to array m aa rha h 
// console.log(Array.prototype);
// // to confirm array ka prototype array hi h 
// console.log(Array.isArray(Array.prototype));


// // function ka object m aata h 
// function hello(){
//     console.log("hello");
// }
// // is line s dekho prototype jo object m aa rha h 
// console.log(hello.prototype)



// --------------------------------------------------------
// ---------------------------------------------------------

// Change prototype 
function hello(){
    console.log("hello");
}
console.log(hello.prototype);

hello.prototype=[];
// we can se now  prototype changed  to empty array 
console.log(hello.prototype);

hello.prototype.push("1");
console.log(hello.prototype);



