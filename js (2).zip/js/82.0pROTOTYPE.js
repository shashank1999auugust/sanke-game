//PROTOTYPE

// javasript m function function to hota hi h + object nbhi hota h 
// function hello(){
//     console.log("hellow world");
// }
// it will tell function name 
// console.log(hello.name);

// you can add your own properties
// hello.myownproperty="uniquevalue"
// console.log(hello.myownproperty);

// function provide more useful properties

// when we create a function so it gives us a space which is  empty object {}  and this is 
// called prototype y totally different h [[prototype ]] se

// console.log(hello.prototype);
// this gives us because if we want to add any key value pair  related to the function 
//  then we can add it here 



// only function provides prototype property  
// if(hello.prototype){
//     console.log("prototype is present");
// }
// else{
//     console.log("prototype is not present");
// }


// ----------------------------------------------------------
// -------------------------------------------------

// lets check for object   NO its giving prototype is not present  so only function have prototype
// const hello={
//     key1:"value1"
// }
// if(hello.prototype){
//     console.log("prototype is present");
// }
// else{
//     console.log("prototype is not present");
// }

// -------------------------------------------------------------
// ----------------------------------------------------------
function hello(){
    console.log("hello world");
}
// now how to use prototype here we use that object space  and add property
hello.prototype.abc="abc";
hello.prototype.xyz="xyz";
hello.prototype.sing=function(){
 return "lala la la";
}
// now check .. yes its added 
console.log(hello.prototype);
console.log(hello.prototype.sing());
