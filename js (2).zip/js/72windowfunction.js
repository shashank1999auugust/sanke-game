// this will refer to window object 
// console.log(this)

// we can also write like this  
// console.log(window);

// function myfun(){
//     console.log(this);
// }
// this will print window object if we write this in function simply 
// myfun();



// ------------------------------------------------------------------------------------
// so some developer uses use strict now it will give undefined
function myfun(){
    "use strict"
    console.log(this);
}
myfun();