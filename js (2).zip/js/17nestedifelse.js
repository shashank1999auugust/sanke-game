//NESTED IF ELSE AND PROMPT

let winningnumber=19
//PROMPT TAKES INPUT ON STRING
let userguess= prompt("guess a number");
console.log(userguess);
// console.log(typeof userguess)
//so convert it in no
userguess=Number(userguess)
// console.log(typeof userguess)


if(userguess===winningnumber){
    console.log("your guess is right")
}
else{
    if(userguess<winningnumber){
        console.log("too low")
    }else{
        console.log("too high")
    }
}