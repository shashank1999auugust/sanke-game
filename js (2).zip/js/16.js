//and or operator

// let firstname="harshit";
// let age=22;

// age >18 + firstchar h he kya ?
//And operator check both are true 
// if(firstname[0]=="h" && age>18){
//     console.log("yes")
// }
// else{
//     console.log("no")
// }


//or operator check anyone is true 
let firstname="harshit";
let age=22;
if(firstname[0]=="B" || age>18){
    console.log("yes")
}
else{
    console.log("no")
}
// in above case age is > but firstchar is not B------------- still give true becuase or operator