const user={
    firstname:"harshit",
    
}
console.log(user.firstname);
// this line will give error as there is no  houseno and address in user  
// console.log(user.address.housenuber);

// but for this it will give undefined
// console.log(user.address)

// sometimes it happens that in our object there is not some property , but after some tim it will exist
// like address is not here right now but after siome time it will be here so we want 
// that this line will not give error console.log(user.address.housenuber) isntead give undefined
// lets see how to do  --- use ? .
// Now this will give undefined 
console.log(user?.address?.housenumber);

