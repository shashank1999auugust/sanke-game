
// const user={
//     firstname:"harshit",
//     lastname:"vashishta",
//     email:"harshistvashist@gmail.com",
//     age:2,
//     address:"houseno,colony,pincode,state",
//     about:function(){
//         return `${this.firstname}is ${this.age} years old`;
//     },
//     is18: function(){
//         return this.age>=18;
//     }
// }
// console.log(user.about());
// suppose we need to create 1 lak user .about. we can not create like this agin and again 
// so we create a function 
// 1) which creates a object 
// 2) add key value pair 
// 3) object ko return krega wo fuction 

function createuser(firstname,lastname,email,age,address){
 const user={};
 user.firstname=firstname;
 user.lastname=lastname;
 user.email=email;
 user.age=age;
 user.address=address;
 user.about=function(){
    return `${this.firstname} is ${this.age} years old`;
}
  user.is18= function(){
    return this.age>=18;
}
return user;
}
const user1=createuser("harshit","vashist","harshit@gmail.com",3,"my address");
console.log(user1);
const about=user1.about();
console.log(about);
const is18=user1.is18();
console.log(is18);