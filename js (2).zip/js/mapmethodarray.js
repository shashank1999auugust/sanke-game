// const numbers=[3,4,6,1,8];

// const square=function(number){
//     return number*number;
// }
// // it creates new array  so its imp to return in sqare function .. in foreach/forof it dont create new array
// // there we were printing directly 
//  const squareno=numbers.map(square);
//  console.log(squareno);


// same thing with callback function inside and arrow function 
// const numbers=[3,4,6,1,8];

//  const squareno=numbers.map(function(number){
//     return number*number;
//  })
//  console.log(squareno);


// arrow
// const numbers=[3,4,6,1,8];

//  const squareno=numbers.map((number)=>{
//     return number*number;
//  })
//  console.log(squareno);


// real life example
//  if we need to create a array of usernames
const users=[
    {firstname:"harshit",age:23},
    {firstname:"vaibhav",age:21},
    {firstname:"akash",age:22},
    {firstname:"gaurav",age:24},
]

const usernames=(function(user){
    return user.firstname;
})
const newarray=users.map(usernames);
console.log(newarray);

// using callback inside 
// const usernames=users.map(function(user){
//     return user.firstname;
// })

// using map function 
//  const usernames=users.map((user)=>{
//     return user.firstname;
//  })
//  console.log(usernames);