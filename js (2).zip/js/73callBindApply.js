// const user1={
//     firstname: "harshit",
//     age:8,
//     about: function(){
//         console.log(this.firstname, this.age);
//     }
// }

// const user2={
//     firstname:"mohit",
//     age:9,
// }
// isme kya krna h ki user 1 m about function h  and user 2 m nahi h.apply.but
//  mujhe user 1 k about function ko use krna h pr jo value h wo user 2 ki honi chaie
// normally for user 1 
// user1.about();

// use the below syntax to take properties from user2 object 
// user1.about.call(user2);

// for user 1 
// user1.about.call(user1);


//undefined becuse we use call and nothing passed
// user1.about.call()


// -------------------------------------------------------------------------------------------
// -------------------------------------------------------------------------------------------

// const user1={
//     firstname: "harshit",
//     age:8,
//     about: function(hobby,favmusician){
//         console.log(this.firstname, this.age, hobby, favmusician);
//     }
// }

// const user2={
//     firstname:"mohit",
//     age:9,
// }

// user1.about.call(user2,"guitar","moazrt");


// ----------------------------------------------------------------
// --------------------------------------------------------------------
// function about(hobby,favmusician){
//     console.log(this.firstname, this.age, hobby, favmusician);
// }
// const user1={
//     firstname: "harshit",
//     age:8,
// }

// const user2={
//     firstname:"mohit",
//     age:9,
// }
// about.call(user1,"guitar","moazrt");

// -----------------------------------
// ------------------------------------

// APPLY same as call  internally uses call

// function about(hobby,favmusician){
//     console.log(this.firstname, this.age, hobby, favmusician);
// }
// const user1={
//     firstname: "harshit",
//     age:8,
// }

// const user2={
//     firstname:"mohit",
//     age:9,
// }
//DIFFERENCE instead of sending extra arguments like this 
// about.call(user1,"guitar","moazrt");

// send like this  user array to send rest all arguments
// about.apply(user2,["guitar","moazrt"]);


// -------------------------------------------------------------------------------
// -------------------------------------------------------------------------------
// BIND  y function return krta h to usko call krna pdta h tbhi chlega wo 
// function about(hobby,favmusician){
//     console.log(this.firstname, this.age, hobby, favmusician);
// }
// const user1={
//     firstname: "harshit",
//     age:8,
// }

// const user2={
//     firstname:"mohit",
//     age:9,
// }
//    yha save kraya bind k dwwara kia hua function jo return aaya h 
  // const func=about.bind(user1,"guitar","bach");
//   is func ko call krne pr bakio (call,apply) ki trh print krega 
  // func();

  