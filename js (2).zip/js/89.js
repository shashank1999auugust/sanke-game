class animal{
    constructor(name,age){
        this.name=name;
        this.age=age;
    }
    eat(){
        return`${this.name} is eating`;
    }
    issupercute(){
        return this.age<=1;
    }
    iscute(){
        return true;
    }
    }
    class dog extends animal{
         constructor(name,age,speed){
            // name and age super calss ko de di wo set kr dega  
            super(name,age);
            // speed y set kr dega 
            this.speed=speed;
         }
         run(){
            return `${this.name} is running at ${this.speed}kmph`;
         }
    }
   //object / instance 
    const tommy= new dog("tommy",3,45);
    console.log(tommy);
    console.log(tommy.run());