// map reduce for each y jo bbi thi wo array ko mutate nahi kr rhe the , y mutate krega (change)

// basically y check krta h ki a-b>0 h ya nahi agr >0 h to hum b ko phle likhte h fir a ko
// for example 1200,410  so 1200-410= 790 and 790>0 so out will be 410,1200 ASCII M DEAL KRTA H 
// const numbers=[5,9,1200,410,3000];
// numbers.sort((a,b)=>a-b);
// console.log(numbers);



// for descending sort 
// const numbers1=[5,9,1200,410,3000];
// numbers.sort((a,b)=>b-a);
// console.log(numbers);

// amazon website sort product as compared to price
const products=[
    {productid:1,productname:"p1f",price:300},
    {productid:2,productname:"p1d",price:100},
    {productid:3,productname:"p1de",price:500},
    {productid:4,productname:"p1aj",price:200},
    {productid:5,productname:"p1",price:400}
]
//low to high store it in the new array  (so that origianl array will not change)
//  aise bhi kr skte h clone const newarray= products.slice(0).sort(a,b)=>{ //
const newarray= [...products].sort((a,b)=>{
    return a.price-b.price;
});
// or we can write like this
// products.sort((a,b)=>a.price-b.price);

console.log(newarray);
// we can check original array is not disturbed 
// console.log(products)