//when we pass function to a function  and then we called that function which is passed.
// is known as callback function 

//  function myfun2(){
//     console.log("inside my func2");
//  }
//  function myfunc(a){
//     // here  a is myfun2 which is passed in this function
//     // we can call a now
//     a();
//  }
//  myfunc(myfun2);






function myfun2(name){
    console.log("inside myfun2");
    console.log(`your name is ${name}`);
}

function myfun(callback){
    console.log("hello there i am fnction and i can ....");
    callback("shashank");
}
myfun(myfun2);