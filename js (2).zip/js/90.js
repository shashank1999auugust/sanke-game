class animal{
    constructor(name,age){
        this.name=name;
        this.age=age;
    }
    eat(){
        return`${this.name} is eating`;
    }
    issupercute(){
        return this.age<=1;
    }
    iscute(){
        return true;
    }
    }
    class dog extends animal{
         constructor(name,age,speed){
            // name and age super calss ko de di wo set kr dega  
            super(name,age);
            // speed y set kr dega 
            this.speed=speed;
         }
         eat(){
            return `modified eat: ${this.name} is eating`
         }
         run(){
            return `${this.name} is running at ${this.speed}kmph`;
         }
    }
   //object / instance 
    // const tommy= new dog("tommy",3,45);
    // console.log(tommy);
    // console.log(tommy.run());
    // console.log(tommy.eat());

//   apne wala hi method call krta h parent .location. child ka nahi 
    const animal1=new animal("sheru",2)
    console.log(animal1);
    console.log(animal1.eat());