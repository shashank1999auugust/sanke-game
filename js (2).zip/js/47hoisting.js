// function hello(){
// console.log("hello");
// }
// hello();

// we can call this function before declare

// hello();
// function hello(){
//     console.log("hello");
//     }
  

    // in function expression case it will not work 
    // it will give error

//  hello();
//  const hello=function (){
//     console.log("hello");
//     }

    // for arrow function also it will give error
    // hello();
    // const hello= ()=>{
    //    console.log("hello");
    //    }



    // agr var use krke variable bnaya and usse phle use access kia to undefined aaega
    // console.log(hello);
    // var hello= "hello world";
    
    // const and let m error aaega
    // console.log(hello);
    // const hello= "hello world";


    console.log(hello);
    let hello= "hello world";