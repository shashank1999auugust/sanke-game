//  let and const are block scope
//var is functional scope

// function myapp(){
//     if(true){
//         // we use let 
//         let firstname="shashank";
//         console.log(firstname);
//     }
    
        // this will give error becuse we use let above
    //     if(true){
    //      console.log(firstname);
    //     }
    // }
    
    // myapp();



    // 2nd time check for const
    // function myapp(){
    //     if(true){
    //         // we use const
    //         const firstname="shashank";
    //         console.log(firstname);
    //     }
        
            // this will give error becuse we use const above
        //     if(true){
        //      console.log(firstname);
        //     }
        // }
        
        // myapp();


        // 3rd time check for var
        function myapp(){
            if(true){
                var firstname="shashank";
                console.log(firstname);
            }
            
                // this will work becuse we use var above and var is functional scope 
                //so we can use it anywhere in myapp
                if(true){
                 console.log(firstname);
                }
            }
            
            myapp();