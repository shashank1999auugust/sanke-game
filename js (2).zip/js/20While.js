let i=0;
//0 to 9 print
while(i<=10){
    console.log(i)
    i++;
}