//for off
//let fruits=["apple", "banana","orange","pineapple","mango"];
// for(let fruit of fruits){
//     console.log(fruit);
// }


// for in  --> this will give index 

// let fruits=["apple", "banana","orange","pineapple","mango"];
// for(let fruit in fruits){
//     console.log(fruit);
     //console.log(fruits[fruit])
// }

 
// for(let i=0; i<fruits.length; i++){
//     console.log(fruits[i])
// }