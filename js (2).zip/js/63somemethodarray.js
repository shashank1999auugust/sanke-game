//SOME METHOD BHI TRUE YA FALSE RETURN KRTA H
// const numbers=[3,5,1,9];
// // kya ek bhi aisa no h jo even h 
//  const ans=numbers.some((number)=>{
//  return number%2===0;
// });
// console.log(ans);


// check any producrt whose price is greater than 1 lakh 
const usercart=[
    {productid:1,productname:"mobile",price:12000},
    {productid:2,productname:"laptop",price:22000},
    {productid:3,productname:"tv",price:15000},
    {productid:3,productname:"macbook",price:250000},

];
const ans=usercart.some((product)=>{
    return product.price>100000;
});
 console.log(ans);