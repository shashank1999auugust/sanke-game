//EVERY METHOD RETURNS TRUE OR FALSE

// to check whether all elements in the array are even or not 
// const numbers=[2,4,6,8,10];
//  const ans=numbers.every((number)=>{
//     return number%2===0;
// });
// console.log(ans);

const usercart=[
    {productid:1,productname:"mobile",price:12000},
    {productid:2,productname:"laptop",price:22000},
    {productid:3,productname:"tv",price:15000},
];
// check every product is less than 30000 
 const ans=usercart.every((product)=>{
    return product.price<30000;
});
console.log(ans);