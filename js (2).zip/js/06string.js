let firstname= "shashank";
console.log(firstname[0]);
// for length
console.log(firstname.length);

// last element position

console.log(firstname.length-1)

// last element value
// console.log(firstname[firstname.length-1])

