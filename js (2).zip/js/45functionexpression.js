// function expression 

const sumof2numbers=function(num1,num2){
    return num1+num2;
}
const returnedvalue=sumof2numbers(5,4);
console.log(returnedvalue);


 const iseven= function(num){
    if(num%2===0){
        return true;
    }
    return false;
}

const checkeven=iseven(5);
console.log(checkeven);


 const printfirstchar=function(str){
 return str[0];
}
console.log(printfirstchar("zbc"));



// index of target in array
 const findtarget= function(array,target){
    for(let i=0; i<array.length; i++){
        if(array[i]===target){
          return i;
        }
    }
    return -1;
}

const myarray=[1,3,8,90];
const ans= findtarget(myarray,90);
console.log(ans);
