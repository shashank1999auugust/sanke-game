//  this will give undefined 
// let firstname;
// console.log(typeof firstname);


// firstname="shashank";
// console.log(typeof firstname, firstname);

// null
// let myvariable= null;
// this will give me type object .. but its bug .. they are not correcting  becuase if they corrrct
//  then they need to change all frameworks of javascript
// console.log(typeof myvariable);

myvariable="shashank";
// console.log(typeof myvariable, myvariable)


// bigint
// let myno=123;
// console.log(myno);
// we can store upto this value in an int 
// console.log(Number.MAX_SAFE_INTEGER);

let myno= BigInt(24637383028363739373829273);
// we can also make a no to bigint by adding n to end of it
let samemyno= 123n;
console.log(typeof samemyno);

console.log(myno, typeof myno);
//  we can add two big ints 
console.log(myno+samemyno);

// but we cant add one big int and one int we must convert int to big int to add them 

