// function myfun(){
//     function hello(){
//         console.log("hello world")
//     }
//     return hello;
// }
// const ans=myfun();
// // here ans becomes function because myfun returning function 
// ans();

function myfun(){
    function hello(){
        return "hello world"
    }
    return hello;
}
const ans=myfun();
// here ans becomes function because myfun returning function 
 console.log(ans());