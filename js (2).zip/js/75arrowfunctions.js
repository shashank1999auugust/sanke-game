const sumof2numbers=(num1,num2)=>{
    return num1+num2;
}
const returnedvalue=sumof2numbers(5,4);
console.log(returnedvalue);


 const iseven= (num)=>{
    if(num%2===0){
        return true;
    }
    return false;
}

const checkeven=iseven(5);
console.log(checkeven);


//  const printfirstchar=(str)=>{
//  return str[0];
// }
//shortcut , if one argument we can remove () , if one line than we can remove {} and remobve return
const printfirstchar=str=> str[1];
console.log(printfirstchar("zbc"));

// const printfirstchara=(str)=> { return str[1];}
// console.log(printfirstchara("zbc"));



// index of target in array
 const findtarget= (array,target)=>{
    for(let i=0; i<array.length; i++){
        if(array[i]===target){
          return i;
        }
    }
    return -1;
}

const myarray=[1,3,8,90];
const ans= findtarget(myarray,90);
console.log(ans);
