const user1={
    firstname: "harshit",
    age:8,
    about: function(){
        console.log(this.firstname, this.age);
    }
}
// dont do this mistake  for below line work properly
//  user1.about();

// if we store it  and then call it will give undefined , undefined 
// y islie ho rha h kuki hum about ko call nahi kr rhe bad m kr rhe h myfunc ko so 
// about ki binding us smy user 1 s nahi hui
//  const myfunc= user1.about;
//  myfunc();


// isko shi kaise kre Bind use krna pdta h 
// const myfunc= user1.about.bind(user1);
// myfunc();