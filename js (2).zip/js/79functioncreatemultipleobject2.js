
// akhir kya kamiyan thi functioncreateobject1 m janie is file me 
// function createuser(firstname,lastname,email,age,address){
//     const user={};
//     user.firstname=firstname;
//     user.lastname=lastname;
//     user.email=email;
//     user.age=age;
//     user.address=address;
//     user.about=function(){
//        return `${this.firstname} is ${this.age} years old`;
//    }
//      user.is18= function(){
//        return this.age>=18;
//    }
//    return user;
//    }
//    const user1=createuser("harshit","vashist","harshit@gmail.com",3,"my address");
//    const user2=createuser("harsh","vashist","harshit@gmail.com",3,"my address");
//    const user3=createuser("mohit","vashist","harshit@gmail.com",3,"my address");

//    ------------------------------------------------------------------------------------------------
//   issue no 1
//  y jo 2 method h jitni bar humare user bnenge utni bar y bhi bnenge but iski 1 copy enough h 

const usermethods={
    about:function(){
        return `${this.firstname} is ${this.age} years old`;
    },
      is18:function(){
        return this.age>=18;
    }
}
   
function createuser(firstname,lastname,email,age,address){
    const user={};
    user.firstname=firstname;
    user.lastname=lastname;
    user.email=email;
    user.age=age;
    user.address=address;
    // here we can use refference  this dont create these methods again and again.
    user.about=usermethods.about;
    user.is18=usermethods.is18;
    return user;
   }
   const user1=createuser("harshit","vashist","harshit@gmail.com",3,"my address");
   const user2=createuser("harsh","vashist","harshit@gmail.com",3,"my address");
   const user3=createuser("mohit","vashist","harshit@gmail.com",3,"my address");
  console.log(user1);
  console.log(user1.about())
  console.log(user2);
  console.log(user2.about)
