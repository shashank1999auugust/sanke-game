//clone using object.assign()

const obj={
    key1:"value1",
    key2:"value2"
}
const obj2=obj;
obj.key3="value3"
console.log(obj)
console.log(obj2)

// instead of line 7 write like this 
//spread operator to clone 
// const obj2={...obj};

// or you can write like this 
// const obj2= Object.assign({},obj)