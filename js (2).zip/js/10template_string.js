// template string 
let age=22;
let firstname="shashank";
// we need a string like my name is shashank and my age is 24


// let aboutme= "my name is "+firstname+" and my age is "+age;

// this is template string
// let aboutme=`my name is ${firstname} and my age is ${age}`
// console.log(aboutme);



