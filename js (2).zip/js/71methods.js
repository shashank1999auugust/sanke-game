//methods
//functions inside object

// const person={
//     firstname:"harshit",
//     age:8,
//     about:function(){
//         // console.log("person name is harshit and age is 8");
//         // console.log(`person name is ${firstname} and age is ${age}`);
//         console.log(`person name is ${this.firstname} and age is ${this.age}`);
//     }
// }
// this will give full function 
// console.log(person.about);
//  but i need to call the about function 
// person.about();

// now  in console.log() i want the name and age change whatever is in person i dont want to hardcode it 
// so use in about function   // console.log(`person name is ${firstname} and age is ${age}`);

// but this will give error  so how to write 
// use there  console.log(`person name is ${this.firstname} and age is ${this.age}`); in line 10 


// -----------------------------------------------------------------------------------------------
function personinfo(){
    console.log(`person name is ${this.firstname} and age is ${this.age}`);
}
 const person1={
        firstname:"harshit",
        age:8,
        about:personinfo,
    }
    const person2={
        firstname:"mohit",
        age:18,
        about:personinfo,
    }
    const person3={
        firstname:"nitish",
        age:17,
        about:personinfo,
    }
    // abhi undefined dega y 
    personinfo();
    person1.about();
    person2.about();
    person3.about();