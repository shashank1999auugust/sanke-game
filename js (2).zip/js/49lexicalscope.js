const myvar="lasttimecheck";
function myapp(){
  const myvar="value1";

  function myfunc(){
    const myvar="value59";
    // abhi value 59 wala my var s value lega agr isko comment krenge  to fir value 1 wale s lega
    // agr value 1 wwale ko bhi comment kr denge to function s bhar wale ki value lega 
    console.log("insidemyfunc",myvar)
  }
 
  console.log(myvar);
  myfunc();
}
myapp();