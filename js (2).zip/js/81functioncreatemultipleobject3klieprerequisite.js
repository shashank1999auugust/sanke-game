// const obj1={
//     key1:"value1",
//     key2:"value2"
// }
// const obj2={
//     key3:"value3"
// }

// console.log(obj1.key1);
// console.log(obj2.key3);

// this will give undefined because obj 2 dont have key1 
// ab hum chahte h ki agr obj 2 k pas key 1 nahi h to wo khud s obj 1 k pas jae or uski key 1 print kr de 
// console.log(obj2.key1);

// --------------------------------------------------------------------
// ------------------------------------------------------------------

// const obj1={
//     key1:"value1",
//     key2:"value2"
// }
// we can create obj2 like this also 
// const obj2={}
// obj2.key3="value3"


// console.log(obj2.key3);

// ----------------------------------------------------------------------------
// -----------------------------------------------------------------------------

// there is one more way to create a emptyy object in the  javascript 
const obj1={
    key1:"value1",
    key2:"value2",
}
// obj 2 khali object h .. this is other way (iski wjh s obj 2 obj 1 s link ho jata h )
const obj2=Object.create(obj1); //{}
obj2.key3="value3";
// console.log(obj2.key3);

// ab javascript phle object 2 m check kregi ki key2 h ya nahi agr nahi h to obj 1
//  m kregi check kuki humne unhein link kr dia h  line no 39 me  const obj2=Object.create(obj1)
// console.log(obj2.key2);


// lets print obj2 
// hum dekh paenge [[Prototype]] k andr likha hoga obj1 wali properties  on console
console.log(obj2);

//so conclusion m kh skte h  const obj2=Object.create(obj1); is line s obj2 ka prototype obj 1 set ho gya 



