class animal{
constructor(name,age){
    this.name=name;
    this.age=age;
}
eat(){
    return`${this.name} is eating`;
}
issupercute(){
    return this.age<=1;
}
iscute(){
    return true;
}
}
// const animal1= new animal("tom",2);
// console.log(animal1);
// console.log(animal1.eat());
// console.log(animal1.iscute());

// class dog{
//     constructor(name,age){
//         this.name=name;
//     this.age=age;
//     }
//     eat(){
//         return`${this.name} is eating`;
//     }
//     issupercute(){
//         return this.age<=1;
//     }
//     iscute(){
//         return true;
//     }
// }
// const tommy=new dog("tommy",3);
// console.log(tommy);
// console.log(tommy.eat());


// we can use animal class and we can make dog class
// its  called sub class it do have all the properties and methods of animal class

class dog extends animal{

}
// first it will try to call the constructor of the dog class if no constructor is there then it will 
// call the  constuctor of parent class which is animal 

const tommy= new dog("tommy",3);
console.log(tommy.eat());
console.log(tommy);