// function myfunc(a,b,...c){
//     console.log(`a is ${a}`);
//     console.log(`b is ${b}`);
//     console.log(`c is `,c);
// }
// myfunc(3,4,5,6,7,8,9);

function addALL(...numbers){
    let total=0;
    for(let number of numbers){
     total+=number;
    }
    console.log(total);
    console.log(numbers);
    console.log(Array.isArray(numbers));
}
addALL(1,2,3,4,5);