// jb humare object k andr function hota h to use hum method khte h 
// This is normal key value key is about and value is function 
// const user1={
//         firstname: "harshit",
//         age:8,
//         about: function(){
//             console.log(this.firstname, this.age);
//         }
//     }
//     user1.about();
    

    // --------------------------------------------------
    const user1={
        firstname: "harshit",
        age:8,
        about(){
            console.log(this.firstname, this.age);
        }
    }
    user1.about();
    