let i = 0;
let total = 0;
while (i <= 10) {
    total = total + i;
    i++;
}
console.log(total)
console.log("hello")

// to calculate sum of first n natural no 
// (n*(n+1))/2