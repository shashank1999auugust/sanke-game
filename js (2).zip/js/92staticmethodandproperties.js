class person{
    constructor(firstname,lastname,age){
        this.firstname=firstname;
        this.lastname=lastname;
        this.age=age;
    }
      // static mehod
    static classinfo(){
        return "this is person class";
    }
  // static property
  static desc= "static property";

   get fullname(){
    return `${this.firstname} ${this.lastname}`;
   }

   set fullname(fullname){
        const[firstname,lastname] =fullname.split(" ");
        this.firstname=firstname;
        this.lastname=lastname;
   }
   eat(){
            return`${this.firstname} is eating`;
        }
   issupercute(){
            return this.age<=1;
        }
    iscute(){
            return true;
        }
}

const person1= new person("harshit","sharma",8);
// upr jo bhi sare methods h inko object hi call kr paega 
// for ex 
// console.log(person1.eat());

// we can create methods which are not related to object .. directltly call honge class s
//  this will give error ... 
// person1.classinfo();

// hum in static methods ko directly class s call kr skte h 
console.log(person.classinfo());

// jaise hum baki  property ko access krte h 
console.log(person1.age);

// lets see for static  nhi ho rha y to undefined aa rha h 
// console.log(person1.desc);

// kuki y directly class s call hoti h object s nahi  ab chlega dekho 
console.log(person.desc);