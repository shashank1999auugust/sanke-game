function createuser(firstname,age){

this.firstname=firstname;
this.age=age;

}
// add methods to the prototype of this function 
createuser.prototype.about=function(){
    console.log(this.firstname,this.age);
}
const user1=  new createuser("harshit",6);
// console.log(user1);
user1.about();

// y new keyword s kya kya hua 
// 1)empty object ={}
// 2) return this 
// 3) hume link krne ki jrurat nahi pdi 
// y line use nahi kri humne  Object.create(createuser.prototype)