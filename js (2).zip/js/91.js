// getters and setters



// class Person{
//     constructor(firstname,lastname,age){
//         this.firstname=firstname;
//         this.lastname=lastname;
//         this.age=age;
//     }
    //get lgane s ab yise call krne ki jrurat nahi pdegi .. y propersties ki trh access ho 
    //  jenge object me 
    //  bin get k fullname(){
//     get fullname(){
//     return `${this.firstname} ${this.lastname}`;
//    }
// }
// const person1=new Person("shashank", "sabharwal", "24")
//above if we use get then we can call it like person1.(like property)  agr get nahi likhenge to pura aaega
// console.log(person1.fullname)

// wrna hume aise krna pdta bina get k 
// console.log(person1.fullname())


// ______________________________________________________________________________________


// class Person{
//     constructor(firstname,lastname,age){
//         this.firstname=firstname;
//         this.lastname=lastname;
//         this.age=age;
//     }

//     get fullname(){
//       return `${this.firstname} ${this.lastname}`;
//     }

//     setName(firstname,lastname){
//       this.firstname=firstname
//       this.lastname=lastname
//      }

// }
// const person1=new Person("shashank", "sabharwal", "24")

// console.log(person1.fullname)

// console.log(person1.firstname)
// console.log(person1.lastname)
// // lets change firstname and lastname using setName now 
// person1.setName("new","name")
// // we could have changed like this also 
// // person1.firstname="new"
// // person1.lastname="name"
// //its changed 
// console.log(person1.firstname)
// console.log(person1.lastname)
// _________________________________________________________________________________________________




class Person{
    constructor(firstname,lastname,age){
        this.firstname=firstname;
        this.lastname=lastname;
        this.age=age;
    }

    get fullname(){
      return `${this.firstname} ${this.lastname}`;
    }
    
    set fullname(fullname){
        //destructure kr lia  (fullname.split s bani list ko )
         const[firstname,lastname]=fullname.split(" ")
         this.firstname=firstname
         this.lastname=lastname
    }

}
const person1=new Person("shashank", "sabharwal", "24")

console.log(person1.fullname)

console.log(person1.firstname)
console.log(person1.lastname)

// I want ki agr m y likhu to first name and lastname change ho jae 
// person1.fullname="new name"
// console.log(person1.firstname)
// console.log(person1.lastname)
// upr firstname m new aa jae and lastname m name aa jae , y achieve krne k lie upr   set fullname(fullname){ bnao


// now try again  and see change ho gaya
person1.fullname="new name"
console.log(person1.firstname)
console.log(person1.lastname)



// ________________________________________________________________________________________
