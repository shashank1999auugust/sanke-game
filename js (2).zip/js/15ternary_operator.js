// Ternary operator

let age=19;
let playgames= age>=18?"Yes":"No";
console.log(playgames)