// const myarray=["value1","value2","value3"];
// let[myvar1,myvar2]=myarray;
// console.log(myvar1);
// console.log(myvar2);

//  in this in my var 1 we are storing value 1 and in my var3 we are storing value 3
// const myarray=["value1","value2","value3"];
// let[myvar1, ,myvar3]=myarray;
// console.log(myvar1);
// console.log(myvar3);



// store value 3 and value 4 in seperate array
// const myarray=["value1","value2","value3","value4"];
// let mynewarray=myarray.slice(2)
// console.log(mynewarray)


// shortcut for store value 3 and 4 in mynew Array

// const myarray=["value1","value2","value3","value4"];
// let[myvar1,myvar3 ,...mynewarray]=myarray;
// console.log(mynewarray)