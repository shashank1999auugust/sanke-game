// let firstname= "   shashank     ";
// console.log(firstname.length);
// console.log(firstname)

// strings are immutable...... we use trim to remove spaces but we need to assign it to some variable to update
//  let check =firstname.trim();
//  console.log(check.length);
//  console.log(check)

// let firstname="shashank";

//  firstname =firstname.toUpperCase();
//  console.log(firstname);


// let firstname="SHASHANK";
// firstname=firstname.toLowerCase();
// console.log(firstname);


let firstname ="shashank"
let newstring=firstname.slice(3,5); 
// 3,5 gives element from 3 to 4 
// slice not include ending index so (0,4) gives element from 0 to 3
console.log(newstring);