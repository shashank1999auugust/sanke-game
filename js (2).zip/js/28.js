// primitive vs refference type

// Primitive
// let num1=6;
// let num2=num1;
// console.log("num 1 value is ",num1)
// console.log("num 2 value is ",num2)
// num1++;
// console.log("num 1 value is ",num1)
// console.log("num 2 value is ",num2)


// Refference 
let array1=["item1","item2"]
let array2=array1;
console.log("array 1 is ", array1)
console.log("array 2 is ", array2)

array1.push("item3")

console.log("array 1 is ", array1)
console.log("array 2 is ", array2)

// so we check in refference type array2 is not a new array its the same as array 1 ,
//  if we are changing value in array 1 its also changing in array 2 
//  because it shares the same heap memory , both have same address