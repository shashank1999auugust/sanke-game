// into to variable
// variable can store some info 


// declare a variable
// var firstname="shashank"

//use a var
// console.log(firstname);


//change value
// firstname="shashank sabharwal"

// console.log(firstname)





// _______________________________________________________________________________________________________
// we can use 
// "use strict"
// now if we declare a variable without type then it will throw error 
// secondname="sabharwal"
// console.log(secondname);
// _____________________________________________________________________________________________________

// do the same without use strict . print secondname - now it works fine

secondname="sabharwal"
console.log(secondname);

// ___________________________________________________________________________________________________________

