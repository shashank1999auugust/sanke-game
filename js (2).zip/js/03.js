// rules for naming variables

// 1) cannot start with number 
// var 1value=10;

// we can use number later 
// var value1=10;


// __________________________________________________________________________________
// yu can use only _ underscore or dollar symbol

// first_name (valid)
// _firstname(valid)
//first$name(valid)
// $firstname(valid)
// ______________________________________________________________________________________

// you cannot use spaces 
// first name (invalid)

// ___________________________________________________________________________________
// convention start with small letter and use camel case 