// new keyword

//ise hum constructor function bhi bolte h kuki y humare lie object construct kr rha h 
// y function bina new keyword k kam nahi krega islie iska first leeter capital rkho y convention h
// taki baki developers ko pta rhe (Createuser C capital)
function Createuser(firstname,lastname,email,age,address){
//    y niche wali line ki jrurat nahi h new keyword k time 
    // const user=Object.create(createuser.prototype)
    // user ki jgh this use kro new m 
    // user.firstname=firstname;
    // user.lastname=lastname;
    // user.email=email;
    // user.age=age;
    // user.address=address;
    this.firstname=firstname;
    this.lastname=lastname;
    this.email=email;
    this.age=age;
    this.address=address;
    // return ki jrurat nahi hoti new m 
    // return this;
   }
  
  //  adding usermethods in prototype itself
  Createuser.prototype.about=function(){
    return `${this.firstname} is ${this.age} years old`;
  };
  
  Createuser.prototype.is18=function(){
          return this.age>=18;
      };
  
  Createuser.prototype.sing=function(){
    return "toon na la la laa la";
      };
//    use new keyword here 
   const user1= new Createuser("harshit","vashist","harshit@gmail.com",3,"my address");
   const user2= new Createuser("harsh","vashist","harshit@gmail.com",13,"my address");
   const user3= new Createuser("mohit","vashist","harshit@gmail.com",19,"my address");
  
  
   console.log(user1);
   console.log(user1.about());
   console.log(user1.is18());