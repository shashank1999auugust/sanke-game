//splice method
//start delete insert

const myarray=["item1","item2","item3"];
// to delete  item 2  // 1 st index s start krna h or 1 hi item delete klrna h 
//isme third value nahi denge kuku insert naghi krna kuch 
//  const deleteditem=myarray.splice(1,1);
// console.log(myarray);
// console.log(deleteditem);



//to insert at position 1 
// myarray.splice(1,0,"inserteditem");
// console.log(myarray);

// insert and delete together
// 1st index s start hoke 2 item deleyte and 3 item insert 
myarray.splice(1,2,"inserteditem1","inserteditem2","inserteditem3");
console.log(myarray);

