const users=[
    {userid:1, firstname:'harshit', gende:'male'},
    {userid:2, firstname:'mohit', gende:'male'},
    {userid:3, firstname:'nitish', gende:'male'}
]

for(let user of users){
    console.log(user.userid);
}