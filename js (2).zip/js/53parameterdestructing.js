// const person={
//     firstname:"harshit",
//     gender:"male",
// }

// function printdetails(obj){
//     console.log(obj.firstname);
//     console.log(obj.gender);
// }

// printdetails(person);

// now with destructuring
const person={
    firstname:"harshit",
    gender:"male",
}

function printdetails({firstname,gender,age}){
    console.log(firstname);
    console.log(gender);
    console.log(age);
}

printdetails(person);