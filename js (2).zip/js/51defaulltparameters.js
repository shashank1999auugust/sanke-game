// function addtwo(a,b){
//     return a+b;
// }
// const ans=addtwo(4,5);
// console.log(ans);


// here b=0 is default value
function addtwo(a,b=0){
    return a+b;
}
const ans=addtwo(4);
console.log(ans);