// for in loop and Object.keys 

// to print keys
const person={
    name:"shashank",
    age:24,
    hobbies:["guitar", "coding","gaming"]
}


// to print values
// for(let key in person){
//     console.log(key);
// }
// for(let key in person){
//     console.log(person[key]);
// }

//`this is template string`
// to print key value
// for(let key in person){
//     console.log(`${key} : ${person[key]}`);
// }


// Object.keys gives all keys in an array form
console.log(Object.keys(person));

// to check whether its array or not
const val=(Array.isArray (Object.keys(person)))
console.log(val);

for(let key of Object.keys(person)){
    console.log(person[key])
}