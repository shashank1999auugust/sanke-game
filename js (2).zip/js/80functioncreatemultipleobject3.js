
//  we added one more method sing , suupose we need to add thousands of method 
//  so we add in usermethods and also add there refference in function becuase its important 
// const usermethods={
//     about:function(){
//         return `${this.firstname} is ${this.age} years old`;
//     },
//       is18:function(){
//         return this.age>=18;
//     },
//     sing:function(){
//  return "toon na la la laa la"
//     }
// }
   
// function createuser(firstname,lastname,email,age,address){
//     const user={};
//     user.firstname=firstname;
//     user.lastname=lastname;
//     user.email=email;
//     user.age=age;
//     user.address=address;
//     // here we can use refference  this dont create these methods again and again.
//     user.about=usermethods.about;
//     user.is18=usermethods.is18;
//     user.sing=usermethods.sing;
//     return user;
//    }
//    const user1=createuser("harshit","vashist","harshit@gmail.com",3,"my address");
//    const user2=createuser("harsh","vashist","harshit@gmail.com",3,"my address");
//    const user3=createuser("mohit","vashist","harshit@gmail.com",3,"my address");
  
//   console.log(user1.sing());

//   console.log(user2.sing());



  //                           NOW GO TO FILE functioncreatemultipleobject3klieprerequisite pr

// uske baad waps aao yha or same kam krte h 
const usermethods={
    about:function(){
        return `${this.firstname} is ${this.age} years old`;
    },
      is18:function(){
        return this.age>=18;
    },
    sing:function(){
 return "toon na la la laa la"
    }
}
   
function createuser(firstname,lastname,email,age,address){
    // const user={}; changes as per functioncreatemultipleobject3klieprerequisite.js
    // is line s usermethods prototype m set ho jaenge
    const user=Object.create(usermethods)
    user.firstname=firstname;
    user.lastname=lastname;
    user.email=email;
    user.age=age;
    user.address=address;
    


    
    return user;
   }
   const user1=createuser("harshit","vashist","harshit@gmail.com",3,"my address");
   const user2=createuser("harsh","vashist","harshit@gmail.com",3,"my address");
   const user3=createuser("mohit","vashist","harshit@gmail.com",3,"my address");
  
   console.log(user1);
//    we are able to access because of  const user=Object.create(usermethods)
   console.log(user1.about());
