const key1="objkey1";
const key2="objkey2";

const value1="myvalue1";
const value2="myvalue2";

// now we need to create a object and need to assign above key and value into it

// const obj={
//     key1:value1,
//     key2:value2
// }
// console.log(obj);


// we can see that its not giving key1 which is objkey1.. so use braket for keys 

// const obj={
//     [key1]:value1,
//     [key2]:value2
// }
// console.log(obj);




// other way to do the same  

const obj={}
obj[key1]=value1;
obj[key2]=value2;
console.log(obj);
