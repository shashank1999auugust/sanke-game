// const numbers=[4,2,5,8];

// function multiplyby2(number,index){
//  console.log(`index is ${index}`);
//  console.log(`${number}*2 = ${number*2}`)
// }
// instead of passing like this use for loop
// multiplyby2(numbers[0],0);
// multiplyby2(numbers[1],1);

// for(let i=0; i<numbers.length; i++){
//     multiplyby2(numbers[i],i);
// }

// we can also do like this 
// for each authomatically pass value and index
// numbers.forEach(multiplyby2);


// or we can write like this 
const numbers=[4,2,5,8];
numbers.forEach(function(number,index){
    console.log(`index is ${index}`);
    console.log(`${number}*2 = ${number*2}`);
})


const users=[
    {firstname:"harshit", age:23},
    {firstname:"mohit", age:21},
    {firstname:"nitish", age:22},
    {firstname:"garima", age:20},  
]
// print firstname using foreach loop
// users.forEach(function(user){
//     console.log(user.firstname)
// }
// )

// print firstname using foreach loop but callback function is arrow here
users.forEach((user)=>{
    console.log(user.firstname)
}
)

// using for of loop
// for(let user of users){
//     console.log(user.firstname);
// }