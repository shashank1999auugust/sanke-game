// const cart=["shoes","pant","kurta"];
// const promise= createOrder(cart)//orderId
// //it will show pending because it is taking 5 sec to resolve as per below code 
// console.log(promise)
// promise.then(function(orderId){
//     console.log(orderId)
//     // proceedToPayment(orderId)
// })


// //creating a promise 
// function createOrder(cart){
//     //write new Promise which will have afunction which have resolve , reject
//     //resolve and reject given by javascript
//  const pr= new Promise(function(resolve,reject){
//     //createOrder
//     //validateCart
//     //OrderId
//     if(!validateCart(cart)){
//         const err= new Error("Cat is not valid")
//     reject(err)
//     }
//     //logic of createorder
//     const orderId="12345"
//     if(orderId){
//         setTimeout(function(){
//             resolve(orderId)
//         },5000)
//     }
//  })
//  return pr;
// }
// function validateCart(cart){
// return true;
// // in this case we will get error in console as promise is rejected  it is of red color , we need to write error part also 
// // return false;

// }


// now to reject the promise just return false in validatecart 



// _______________________________________________________________________
// comment all the code above 
// to handle error when prmise fails we do have catch 
// const cart=["shoes","pant","kurta"];
// const promise= createOrder(cart)//orderId
// //it will show pending because it is taking 5 sec to resolve as per below code 
// console.log(promise)
// promise.then(function(orderId){
//     console.log(orderId)
//     // proceedToPayment(orderId)
// })
// //handling error due to promise failure now it will not show in red color error
// .catch(function(err){
//  console.log(err.message)
// })

// //creating a promise 
// function createOrder(cart){
//     //write new Promise which will have afunction which have resolve , reject
//     //resolve and reject given by javascript
//  const pr= new Promise(function(resolve,reject){
//     //createOrder
//     //validateCart
//     //OrderId
//     if(!validateCart(cart)){
//         const err= new Error("Cat is not valid")
//     reject(err)
//     }
//     //logic of createorder
//     const orderId="12345"
//     if(orderId){
//         setTimeout(function(){
//             resolve(orderId)
//         },5000)
//     }
//  })
//  return pr;
// }
// function validateCart(cart){


// return false;

// }

// ________________________________________________________________________________________

//Lets do chaining now  , we want to attach proccedto payment also 
const cart = ["shoes", "pant", "kurta"];
createOrder(cart)
    .then(function (orderId) {
        console.log(orderId)
        return orderId
    })
    .then(function(orderId){
        return proceedToPayment(orderId)
    })
    //isme receive krte h jo bhi aata h 
    .then(function(paymentinfo){
          console.log(paymentinfo)
    })
    .catch(function (err) {
        console.log(err.message)
    })

//creating a promise 
function createOrder(cart) {
    //write new Promise which will have afunction which have resolve , reject
    //resolve and reject given by javascript
    const pr = new Promise(function (resolve, reject) {
        //createOrder
        //validateCart
        //OrderId
        if (!validateCart(cart)) {
            const err = new Error("Cat is not valid")
            reject(err)
        }
        //logic of createorder
        const orderId = "12345"
        if (orderId) {
            setTimeout(function () {
                resolve(orderId)
            }, 5000)
        }
    })
    return pr;
}
function validateCart(cart) {
    return true;
}

function proceedToPayment(orderId){
 return new Promise(function(resolve,reject){
    resolve("payment successful")
 })
}