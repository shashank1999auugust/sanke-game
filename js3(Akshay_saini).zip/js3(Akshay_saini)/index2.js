// const cart=["shoes","pant","kurta"]
//suppose 2 api createorder and proceedtopayment  createorder is asynchronous it will take time 
// createOrder(cart); //orderid
// proceedToPayment(orderid);

// how we handle this is callback  - we wrap proceedtopayment in callback and pass it to createOrder

// createOrder(cart,
//     function(orderid){
//         proceedToPayment(orderid)
//     })

// but there is issue which is inversion of control becuase we have given proceedtopayment to createorder
// and we are blindly trusting it


// how to do this with promises , we will capture this promise 
// promise is a container for future value 

// const promise= createOrder(cart)

// here we will attack a callback function to promise , ( not pass the function)
// promise.then(function(orderid){
//  proceedToPayment(orderid)
// })
// In above code we are attaching a callback function to promise object 
// in this case we will have contol of the program 
// when promise object filled with data then it will automatically call proccedtopayment

// _______________________________________________________________________________

// from here onwards  i can run , real example 
const github_api = "https://api.github.com/users/akshaymarch7"

const user = fetch(github_api)
console.log(user)
// in console it will show pending , because at the point the console is printed that time it was pending 
// because fetch takes time to load data 
user.then(function (data) {
    console.log(data)
})
//till here onwards you can run , real example

// _______________________________________________________________________________
// oply above code can be run else everthing is dummy 
// Pending , fullfiled , rejected promises states  
// promises objects are immutable , once data is filled into it 

// promise -  a promise is a object respresenting eventual completion or failure of asyncronous operation 



const cart = ["shoes", "pant", "kurta"]
// earlier we used to pass it like this  ------ this is callback hell--pyramid of doom
createOrder(cart, function (orderid) {
    proceedToPayment(orderid, function (paymentinfo) {
        showordersummary(paymentinfo, function () {
            updateBalance()
        })
    })
})

// promise chaining comes to avoid this callback hell  ... we write like below code using promise 
const promise = createOrder(cart)
promise.then(function (orderid) {
    proceedToPayment(orderid)
})

// or we can also write like this  we need to make sure write return  when chaining
createOrder(cart).then(function (orderid) {
   return proceedToPayment(orderid)
}).then(function (paymentinfo) {
   return showordersummary(paymentinfo)
}).then(function (ordersummary) {
   return updateBalance(ordersummary)
})

//using arrow function
createOrder(cart)
.then(orderid => proceedToPayment(orderid))
.then(paymentinfo=>showordersummary(paymentinfo))
.then(ordersummary=>updateBalance(ordersummary))