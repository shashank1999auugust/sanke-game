console.log("hello")

console.log("I am shashank")

// above 2 lines will print immediately , because javascript dont wait , 
// so what if we want to run it after 5 seconds so we need to wrap it in the callback function 
setTimeout(function(){
   console.log("Hello I am shashank") 
},3000)
// now it is the job of settimeout to call this function after 3 seconds 
// so using callback is a good way to do asynchronous things in jaascript


