// CALLBACK HELL AND INVERSION OF CONTOL 

// suppose we have ecommerce website 
const cart=["Shoes","Pants", "Kurta"];


// first we need to create order then we need to proced to payment , suppose we have 2 backend api create order and 
// payment Api 

api.createOrder()

api.proceedToPayment()
 
// first we need to create order then only we can procced to payment , this is async operation how we will 
// manage this ?

// here callback can come into picture 
// we will wrap our proceed to payment api in callack function 

api.createOrder( cart,function(){
    api.proceedToPayment()
})
// look at the above order  , now its responsibility of createorder api and call this proceedto function 

//suppose we need to show order summary , we have another api  api.showOrderSummary()

// now we can  go to showordersummary only after proceed to payment 


api.createOrder( cart,function(){
    api.proceedToPayment(function(){
        api.showOrderSummary()
    })
})
//  check above code 
// we passed it to proceedToPayment, now its respomsibility of procced to payment api to procced the
//  payment and call this showorder summary api 

// we have api to update wallet  api.updateWallet()

// we will pass this in a callback function again 

api.createOrder( cart,function(){
    api.proceedToPayment(function(){
        api.showOrderSummary(function(){
            api.updateWallet()
        })
    })
})
// now its responsibility of showordersummary to updatewallet , There is a problem , suppose there are so many api  
// and which are dependent on each other , we fill fall into CALLBACK HELL 
// CALLBACK HELL  ONE CALLBACK INSIDE ANOTHER ALLBACK INSIDE ANOTHER CALLBACK 

// ITS TOUGH TO MANAGE THIS 
// THIS STRUCTURE IS KNOWN AS PYRAMIND OF DOOM

//iNVERSION OF CONTROL 
// IT is another problem we see  when we use callbacks 
// example 
api.createOrder( cart,function(){
    api.proceedToPayment()
})
// in above code  we give proccedtopayment callback function to createorder api , 
// and we are blindly trusting to createorder api , what if it calls proccedtopayment called twice 
//what if callback function never called 
// so here we passed proceedtopayment fucton to createorder 


