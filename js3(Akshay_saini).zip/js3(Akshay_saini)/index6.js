
//  returning value which will automatically converts in promise 

// //always return a promise 
// async function getData(){
//     //IF ITS A PROMISE THEN IT WILL DIRECTLY RETURN A PROMISE OR IT WILL WRAP IT INTO PROMISE AND RETURN
//  return "Namaste"
// }

// const dataPromise=getData()
// // console.log(dataPromise)
// dataPromise.then((res)=>console.log(res))





// ____________________________________________
// using .then 
// function getData(){
//     p.then((res)=>console.log(res))
// }
// getData()
// ___________________________________________________________________________________________________
//  returning a promise 
// const P= new Promise((resolve,reject)=>{
//     resolve("promise resolved value")
// })

// async function getData(){
// return P
// }

// const dataPromise=getData()
// dataPromise.then((res)=>console.log(res))
// ______________________________________________________________________________________________

// const p= new Promise((resolve,reject)=>{
//     resolve("promise resolved value")
// })
// async function handlePromise(){
//     const val =await p;
//     console.log(val)
// }
// handlePromise()

// await can only be used inside async function 

// _____________________________________________________________________________________________


// const p= new Promise((resolve,reject)=>{
//     setTimeout(()=>{
//         resolve("promise resolved value")
//     },10000)
    
// })
// async function handlePromise(){
//     const val =await p;
//     console.log(val)
// }
// handlePromise()

// __________________________________________________________________________
// Older way of handlig promises 
// const p= new Promise((resolve,reject)=>{
//     setTimeout(()=>{
//         resolve("promise resolved value")
//     },10000)
    
// })
// cooment this 
// async function handlePromise(){
//     const val =await p;
//     // JS ENGINE WAS WAITING FOR PROMISE TO RESOLVED 
//     console.log("nAMASTE JAVASCRIPT")
//     console.log(val)
// }
// handlePromise()
// comment till here 

// function getData(){
//     //js engine will not wait to resolve the promise 
//     p.then((res)=>console.log(res))
//     console.log("Namaste Javvascript")
// }
// getData()
// In older way namaste js is printed directly and when promise is resolved then it will print
//  primise resolved vallue 

// now uncomment the above one async await one  and comment getdata() wala function

// NOW WE CAN SEE console.log("nAMASTE JAVASCRIPT") IS ONLY PRINTED AFTER PROMISE IS RESOLVED 
// _____________________________________________________________________________________________________________
// iN THIS CASE WILL OUR PROGRAM WAIT FOR 2 TIMES ? ??????? ANS IS ---no 
// const p= new Promise((resolve,reject)=>{
//     setTimeout(()=>{
//         resolve("promise resolved value")
//     },10000)
    
// })
// async function handlePromise(){
//     const val =await p;
//     console.log("nAMASTE JAVASCRIPT")
//     console.log(val)

//     const va2 =await p;
//     console.log("nAMASTE JAVASCRIPT 2")
//     console.log(val)
// }
// handlePromise()
// ____________________________________________________________________________________
// what will happen in this case we have 2 promises 

// const p1= new Promise((resolve,reject)=>{
//     setTimeout(()=>{
//         resolve("promise 1 resolved value")
//     },10000)
    
// })
// const p2= new Promise((resolve,reject)=>{
//     setTimeout(()=>{
//         resolve("promise 2 resolved value")
//     },5000)
    
// })
// async function handlePromise(){
//     const val =await p1;
//     console.log("nAMASTE JAVASCRIPT")      //  will it wait here 10 second 
//     console.log(val)

//     const va2 =await p2;
//     console.log("nAMASTE JAVASCRIPT 2")   // will it wait here 5 seconds again ???
//     console.log(val)
// }
// handlePromise()

// promise 2 was resolved in 5 seconds but still next lines were not printed , It printed together 
// after promise 1 also resolved 

// ______________________________________________________________________________________

// Reverse the time and check now , make 10 sec to 5 sec , and 5 sec to 10 sec
const p1= new Promise((resolve,reject)=>{
    setTimeout(()=>{
        resolve("promise 1 resolved value")
    },5000)
    
})
const p2= new Promise((resolve,reject)=>{
    setTimeout(()=>{
        resolve("promise 2 resolved value")
    },6000)
    
})
async function handlePromise(){
    const val =await p1;
    console.log("nAMASTE JAVASCRIPT")      //  will it wait here solve after 5 second 
    console.log(val)

    const va2 =await p2;
    console.log("nAMASTE JAVASCRIPT 2")   // will it wait here wait again for 6 sec? seconds again ???
    console.log(val)
}
handlePromise()

// we can see program first waited for 5 seconds and after that  it waited only 1 second 