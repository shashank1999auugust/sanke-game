//S2 EP-5  THEORY
// Promise.all i used for parallel api calls 

// it takes array of promises 
 // 1) promise.all([p1,p2,p3])
// suppose p1 takes 3s  p2 takes 1s  p3 takes 2s  and suppose all are success 

// -->output will be array  [ result of all promises]
// [ val1 val2 val3 ] 
// promise.all takes 3 second to give the final result array val1, val2 val3 
// It will wait for all of them to finish , then collect the result , then give it to us 
// ___________________________________________________________________

// what if any of the promise fails ?

// 2)promise.all([p1,p2,p3])
// one of these rejected 
//  p1 takes 3s , p2 takes 1 second , p3 takes 2 seconds
// after 1 second p2 get rejected 
// as soon as any of the promise gets rejected , promise . all will show us failure 
// output will be error and it will the same error which p2 gives 
// as soon as error happened error will shows , so it takes 1 second , it will not wait for other promise
//  to success or failure  , 
// what will happen to p1 and p3 ? will that get cancell , NO --- we cant cnacel the promise inbetween 
// these promises will eventually accept or reject its depend on them  , but promise.all will get rejected   
//  as soon as any of the promise get rejected 
// _____________________________________________________________________________________
//  the above case is not good  suppose  if 9 out of the promise resolve and 1 failed ,we want the result 
//  of the 9 of them but in above case it was directly throwing error as soon as any of the promise get failed 
//3) promise.allsetteled([p1,p2,p3])
                    // 3s  2s  1 s 
                    // in this case if everyone successful after 3 sec we will get [val1, val2, val3]

    // in case if any of them get rejected  suppose p2 get rejected p2 takes 2 second in this . 
    // It will still wait for all promises to get settled ..( wait till 3 second )
    // after 3 seconds it will give us the result 
    //   output will be [ val1,error , val3]
    // ______________________________________________________________________________________________
    // we can call FAIL FAST to promise.all()
    // __________________________________________________________________________________
    // 4) Promise.race 
    // Promise.race([p1,p2,p3])
                //  3s 1s  2s 
                // As soon as first promise is resolved , it will give us the result  of p2 which
                // is VAL2 ...AbortController..... it will give us the value of first settled promise 

                // what if first promise was rejected 
                // suppose p2 rejected after 1 second then what will happen?
                // Error will be throw , which will come from p2 
                // It will return the result of first setted promise whether its failure or settled
                //it will not wait for others promises to success or failure 

// _____________________________________________________________________________________________________

// promise.any([p1,p2,P3])
            //   3s 1s 2s 
// it is similar to race , whenever the first promise get successfull . 
// in promise.any we will wait for the first success ,
// suppose p2 become successful then it will return VAL2 
// WHAT IF P1 GETS REJECTED , IT WILL CHECK NEXT ORMISE WHICH IS P3 WHICH TAKES 2 S SO IF IT IS SUCCESSFULL 
// THEN IT WILL return result from p3 , if p3 also rejected , then it will check net promise which is p1 , 
// so if p1 successfull then the value will be val1 . what if all of them gets rejected 
// then it will return a array of failure which contains all the errors 
// [ERROR1,ERROR2,ERROR2]
