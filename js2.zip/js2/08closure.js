// closures 


//function can return functions

// function outerfunction(){
//     function innerfunction(){
//         console.log("hello word");
//     }
//     return innerfunction;
// }

// const ans = outerfunction();
// console.log(ans);
// ans();

// ____________________________________________________________________________________________
function printfullname(firstname,lastname){ //1
    function printname(){                         //f1
        console.log(firstname,lastname);                             //     ans-f1
    }
    return printname;            //f2
}

const ans = printfullname("harshit","sharma");//2

ans();//3

      //  global execution context

// -----------------------------------------------------------------------------------------------------

//  CODE EXECTUTION PHASE                     |                      GLOBAL MEMORY / CREATION PHASE
//                                            |
//                                            |                         window:{}
//                                            |                         this:window{}
//                                                                   f printfullname{}
//                                            |                        ans:uninitialized
//


// code execution

// 1) kuch nahi hoga phle s hi h function global memory m 
// 2) print fullname call hoga to wo ek new function h so ek function execution context bnega 
// ab function exection  se  waps aane k bad ans m wo store ho jaega jp return aaya h 
// yani y store hoga  ans m // f2) return printname 
//y store hoga  function printname(){                         
//     console.log(firstname,lastname);          
// }

// 3) ans call hoga  ek or function execution bnega 


//function execution context printfullname k lie
// -----------------------------------------------------------------------------------------------------

//  CODE EXECTUTION PHASE                     |                      local MEMORY / CREATION PHASE
//                                            |        
//                                            |            arguments:["harshit","sharma"]
//                                                         firstname:harshit
//                                                         lastname:sharma
//                                                          printname{}   

// f1) kuch nahi hoga 
// f2) return printname 
//  y return hoga    function printname(){                         
//     console.log(firstname,lastname);          
// }
// yha pr function exectution khtm waps upr global execution pr jao



                        // ans function execution 
// -----------------------------------------------------------------------------------------------------

//  CODE EXECTUTION PHASE                     |                      local MEMORY / CREATION PHASE
//                                            |        
//                                            |             arguments[...]

// execution
// ans-f1   y print krne ko bol rha h firstname lastname but ans function execution m to h hi nahi 
// firstname and lastname 
// chlo koi na hum iske lexical environment m dekh lete h  jo ki global h and usme bhi nahi h 
// but print to ho rha h to kaise ? jb bhi hum kisi function ko return krenge kisi or function s 
// jaisa ki ismme h hum printname name k function ko return kr rhe h print fullname name k
 //function m s  to jb y  printname function return hoga to khali hath nahi hoga  y jha present tha 
 //jo ki  print fullname h uski local memory ko sath leke return hoga ise hi hum closure khte h 
//  or hum dekh skte h uske andr firstname and lastname present h 

// last m print ho jaega 