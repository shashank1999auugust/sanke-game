function hello(x){    //1
    const a="varA";                   //f1
    const b="varB";                   //f2
    return function(){                //f3
        console.log(a,b,x);                           //ansfunction1
    }
}
const ans=hello("arg"); //2
ans();   //3

    //  global execution context

// -----------------------------------------------------------------------------------------------------

//  CODE EXECTUTION PHASE                     |                      GLOBAL MEMORY / CREATION PHASE
//                                            |
//                                            |                         window:{}
//                                            |                         this:window{}
//                                            |                       function: hello{}
//                                            |                       ans:uninitialized
//                                            |                  


//  global execturtion
// 1st) kuch nahi hoga 
// 2) jb second chlegi to hello function call ho rha h to ek function execution context bnega 

// after function execution waps yha aao . ab yha pr wha s returned function aaega jo ans m store hoga

// 3) ab ans ko call kro ek or functionnexecution context create hoga 




// hello function execution 
// -----------------------------------------------------------------------------------------------

//  CODE EXECTUTION PHASE                     |                      Local MEMORY / CREATION PHASE
//                                            |
//                                            |                         arguments["arg"]
//                                                                       x:arg
//                                                                      a:uninitialized
//                                                                       b:uninitialized
//                                                                       function:{}
// execution
// f1) a ki value uninitialized s hatkr varA ho jaegi  
// f2) b ki value uninitialized s hatkr varB ho jaegi 
// f3) function return hoga ab lekin apne lexical environment yani hello ki properties 
// a and b ki value  sath leke return hoga 



// function execution context for ans 
// -----------------------------------------------------------------------------------------------

//  CODE EXECTUTION PHASE                     |                      Local MEMORY / CREATION PHASE
//                                            |
//                                            |                         arguments[]
//
//execution
// ansfunction1) jb execute hogi to print kr degi a,b, and x 
// a and b ki value halaki iske pas thi nhi na hi iske lexical envirronment m h 
// but  wo closure s aai h 