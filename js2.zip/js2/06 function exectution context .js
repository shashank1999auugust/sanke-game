// function exectution context 
let foo="foo";                                //1
console.log(foo);                             //2
function getfullname(firstname,lastname){     //3
 console.log(arguments);                 //f1
 let myvar="variable inside func";       //f2
 console.log(myvar);                     //f3
 const fullname=firstname + " " + lastname; //f4
 return fullname;     //f5
}

const personname=getfullname("harshit","sharma"); //4
console.log(personname);                          //5

// -----------------------------------------------------------------------------------------------------

//  CODE EXECTUTION PHASE                     |                      GLOBAL MEMORY / CREATION PHASE
//                                            |
//                                            |                         window:{}
//                                            |                         this:window{}
                                                                        // let foo:uninitialized
                                                                        // function getfullname{---
                                                                    // --------------------}
                                                                //    const personname=uninititalised
// _____________________________________________________________________________________________________

                        //   Global Eecution 

//  1 st line )foo=uninitialised s chang hoke foo= "foo"
// 2nd line)       foo
// 3rd line)  done 

// 4thline) ek function call kr rhe h so NEW exection context create 

// isme ab personname uninitialised s change hoke real vaue aa jaegi jo function exectution context s aai hogi 

//5)jb niche wala pura function execurion context run ho jaega to waha s return m jho aaega print kro
// harshit sharma 



                //    function execution context 

// -----------------------------------------------------------------------------------------------------

//  CODE EXECTUTION PHASE                     |                      local MEMORY / CREATION PHASE
//                                            |
//                                            |                      array like object .. 
//                                                                   indexing use and length property
//                                                 isme array like object hota h jo ki arguments[ harshit , sharma]
                                                    // function k  jo parameter honge unki value set hogi
                                                    // firstname:harshit , lastname:sharma
                                                    // my var : uninitialised 
                                                    // fullname : unitialised 


                                  // execution function 

// 1st line od function f1)        [harshit sharama]

// f2) myvar unititalised s change krke.."myvar:variable inside func"
// f3)              " variable inside func"

// f4)   full name =harshit sharma
// f5) return  harshit sharma
//  waps global execution pr jao or uski bachi hui lines chlao 
                      





