// EARLY ERROR CHECKING 
console.log(this);
console.log(window);
console.log(firstname);
var firstname= ."hrshit";

// in this file we can see before even exectution of very fist line in our console there is a error  
// because of the line 5th 