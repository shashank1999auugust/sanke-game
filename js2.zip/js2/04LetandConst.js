// console.log(firstname);   //1)
// in case of let  and const  inki bhi hoisting hoti h y memory m to hote h but useless
// let firstname="harshit";  //2)
// const firstname="harshit";  //2)
// console.log(firstname);   //3)


// Global execution context   1) creation phase 2) code execution phase 
// ____________________________________________________________________________________________________

                           // GLOBAL EXECUTION CONTEXT 
// -----------------------------------------------------------------------------------------------------

//  CODE EXECTUTION PHASE                      |                      GLOBAL MEMORY / CREATION PHASE
//                                             |
//                                             |                       WINDOW:{}
//                                             |                      THIS: WINDOW{}
//                                             |                      firstnale: uninitialized
//                                             |                   


                                    // console
// ________________________________________________________________________________________________

// 1st) execute    console.log(firstname)  
// this will give error  Cannot access 'firstname' before initialization
// jb tk execution k time variable ki value uninitialised s koi value nahi de dete tb tk we can 
// call it temporal dead zone
//let and const k case m bhi hoisting hoti h , mtlb phli line k execute hone s phle hi firstname global 
// memory m hota h firstname  pr wo uninitialzed hota h 

// first ko comment kr do fir hi chlegi 2nd 3rd 
// 2nd) execute         (firstname =harshit ho jaega in global memory) phle y unitialised tha 
// 3rd)                      harshit 


// ___________________________________________________________________________________________________

// console.log(firstname);

// let firstname="harshit";

// error :  Cannot access 'firstname' before initialization
// _____________________________________________________________________________________________________

// let firstname;
// console.log(firstname);

// op: undefined
// ____________________________________________________________________________________________
// const firstname;
// console.log(firstname);

// op: Missing initializer in const declaration 
// ____________________________________________________________________________________________

