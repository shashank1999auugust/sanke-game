
//function expression
console.log(myfunction); //undefined
myfunction();// in this case it will give error        1st)

var myfunction= function(){                       //   2nd)
 console.log("this is my function");        
}
// myfunction(); comment line 4 and then try 


// COMPILATION      1) EARLY ERROR CHECKING .. 
// ____________________________________________________________________________________________________
                      //NOERROR 

                 // 2)          GLOBAL SCOPE 
// ____________________________________________________________________________________________________
                    //    my function : undefined



//Execution        global exectution context 
//1) creation phase 2)execution phase

// -----------------------------------------------------------------------------------------------------

//  CODE EXECTUTION PHASE                     |                      GLOBAL MEMORY / CREATION PHASE
//                                            |
//                                            |                         window:{} - browswe provide krta h
//                                            |                         this:window{}
//                                            |                         myfunction:undefined 

//  -------------------------------------------------------------------------------------------                                                                    


// console 
// _______________________________________________________________________________________________

// 1st                                 undefined  in case of function expression 

// 2st line   execute k time  myfunction()  error de dega  kuki abhi to y un defined h 
// myfunction is not a function 








// stack  me     
// |GEC |
// | __ |