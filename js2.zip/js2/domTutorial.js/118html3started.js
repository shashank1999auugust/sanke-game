                    // USE INDEX3.HTML

//static list vs live list 


// static list niche console wale m 5 hi dikhaenge sixth add nahi hoga

//-------------------------------------------------------------- queryselector all humein static list degi

// const listitems= document.querySelectorAll(".todo-list li");
// console.log(listitems)
// const sixthli= document.createElement("li");
// sixthli.textContent="itrem 6";
// const ul= document.querySelector(".todo-list");
// ul.append(sixthli)
// console.log(listitems);




// __________________________________________________________________________
// --------------------------------------------------------------getelements by something hume live list degi 

// const ul= document.querySelector(".todo-list");
// ul k adr jitne bhi li h 
// const listitems= ul.getElementsByTagName("li");
// console.log(listitems)
// const sixthli= document.createElement("li");
// sixthli.textContent="itrem 6";
// ul.append(sixthli)
// console.log(listitems);

// isme 6 aaegi console pr bhi yani y live list h 