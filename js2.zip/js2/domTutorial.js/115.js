// another ways to add...
//dont use generally use 114 file methods

// unordered list k andr add kte h 
const todolist =document.querySelector(".todo-list")
//beforeend means jha pr todolist khtm ho rhi h wha pr // it works like append 
todolist.insertAdjacentHTML("beforeend","<li>TEACH STUDENTS 1</li>")
todolist.insertAdjacentHTML("afterbegin","<li>TEACH STUDENTS 2</li>")
todolist.insertAdjacentHTML("beforebegin","<li>TEACH STUDENTS 3</li>")
todolist.insertAdjacentHTML("afterend","<li>TEACH STUDENTS 4</li>")




