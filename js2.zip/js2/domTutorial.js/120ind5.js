//index5.js yha s 

// TARIKA 2

// const btn=document.querySelector(".btn-headline");
// console.log(btn);
// console.dir(btn);
// btn.onclick= function(){
//     console.log("you clicked me");
// }

// __________________________________________________________________________________________________

// 3rd tarkika 
// const btn=document.querySelector(".btn-headline");
// //method-----addeventlistener
// // console.log(btn);
// function clickme(){
//     console.log("you clicked me !!!!!!");   
// }
// btn.addEventListener("click", clickme)



// or we can write like this
// const btn=document.querySelector(".btn-headline");
// btn.addEventListener("click", function(){ 
//     console.log("you clicked me ")
// });


// or use arrow function 
// const btn=document.querySelector(".btn-headline");
// btn.addEventListener("click",()=>{
//     console.log(" through arrow function you clicked me ")
// })