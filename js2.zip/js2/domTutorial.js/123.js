// INDEX6.HTML
//EVENT OBJECT 
// const firstbutton = document.querySelector("#one");
// firstbutton.addEventListener("click" ,function(){
// console.log(this);
// })




// jb bhi kisi bhi element pr eventlistener add hoga to browser 

// js engine------line by line execute krta h 
//browser -- js engine + extra features 
// browser --- js engine + webapi

// jab browser ko pata chla ki user n event perform kia 
// jo hum listen kr rhe h 
// browser-----------2
// 1) call back function js engine ko degi  to execute function(){
    // console.log(this);
    // })

    // 2)callback function ke ssath browser jo event hua h uski information bhi dega
    // y 2nd no wali info hume ek object k form m milegi .. we can recieve that as an argument in the function
    // check event is object 
// const firstbutton = document.querySelector("#one");
// firstbutton.addEventListener("click" ,function(event){
// console.log(this);
// console.log(event);
// })


// ___________________________________________________________________________________________
// example kya ho rha h upr y smjne k lie basically browser n kuch chize function ko
//  di or call kr lo ab us function ko 


// function hello(abc){
//     console.log(abc)
// }
// hello({firstkey:"value1", secondkey:"value2"})

// so y jo upr hello function call ho rha h or usme object pass kr rhe h kuch isi trike s browser 
// object pass krta h event information ka 



// _____________________________________________________________________________________________________

// const allbuttons=document.querySelectorAll(".my-buttons button");

// for(let button of allbuttons){
//     button.addEventListener("click",function(){
//         console.log(this.textContent);

//     })
// }

// __________________________________________
// upr wala arrow function m krenge to hume pta h undefined aata h 
// const allbuttons=document.querySelectorAll(".my-buttons button");

// for(let button of allbuttons){
//     button.addEventListener("click",()=>{
//         console.log(this.textContent);

//     })
// }

// ______________________________________________________________

// but we can recieve event in callback function jo hune upr pada jo browser deta h object k roop m 
// const allbuttons=document.querySelectorAll(".my-buttons button");

// for(let button of allbuttons){
//     button.addEventListener("click",(e)=>{
//         console.log(e.target);
//         console.log(e.currentTarget);
      
//     })
// }