// some old methds to support poor internet explorer  isme append ,prepend ,remove , before after 
// y sab kam nahi krte IE m 
//appendchild
//insertbefore
//replacechile
//removechild

// const ul = document.querySelector(".todo-list");
// const li=document.createElement("li");
// li.textContent="neww todoo";
// ul.appendChild(li);
// ________________________________________________________________________________

// const ul = document.querySelector(".todo-list");
// const li=document.createElement("li");
// const referencce=document.querySelector(".first-todo")
// li.textContent="neww todoo";
// ul.insertBefore(li,referencce);

// _________________________________________________________________________________

// const ul = document.querySelector(".todo-list");
// //new element 
// const li=document.createElement("li");
// li.textContent="neww todoo";

// // now we need to remove refernece and add new element 
// const referencce=document.querySelector(".first-todo")

// ul.replaceChild(li,referencce);

// check its replaced now 


// ________________________________________________________________________________________

const ul = document.querySelector(".todo-list");
const referencce=document.querySelector(".first-todo");
ul.removeChild(referencce);

// _____________________________________________________________________________
// removed 