// ab nodelist pr for loops dekhenge abhi tk html collection pr dekha tha 
// queryselectorall hume nodelist deta h 
let navitems=document.querySelectorAll("a");
console.log(navitems);

// nodelist m hum simple for 
//                for of 
//             for each 
// y 3 no loop use kr skte h 
//simple for loop
// for(let i=0; i<navitems.length; i++){
//     // console.log(navitems[i]);
//     const navitem= navitems[i];
//     navitem.style.backgroundColor="#fff";
//     navitem.style.color="red";
//     navitem.style.fontWeight="bold";
// }

// for of loop

for(let navitem of navitems){
    navitem.style.backgroundColor="#fff";
        navitem.style.color="red";
        navitem.style.fontWeight="bold";
}


// for each method 
// navitems.forEach((navitem)=>{
//     navitem.style.backgroundColor="#fff";
//     navitem.style.color="red";
//     navitem.style.fontWeight="bold";
// })
