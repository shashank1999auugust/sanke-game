//change text -------------->textcontext and inner text property 
// our goal is to select manage your tasks which is writen in out website and we need to change this text
// lets check so manage your tasks ko humne ek id di hui h html file m main-heading 
// lets select this elemnt using getelement by id 
// const mainheading = document.getElementById("main-heading");
// upr wali line ek object return krti h we know so uske pas kafi methods hote h 
// console.dir(mainheading) check in this we have a method textcontent
// y text content de degi y line 
// console.log(mainheading.textContent);

// lets change thi value 
// mainheading.textContent="This is something else";

// lets check whether changed or not .... yes its changed 
// console.log(mainheading.textContent);




// ___________________________________________________________________________________________________
// lets chenge html file little bit add a span tag and add hello in that main-heading
// now do the same things above 
// const mainheading = document.getElementById("main-heading");
// iise hum dekhenge ki manage your tasks k sath hello bhi print ho tha h halanki Wo humari 
// website pr visible nahi h
// console.log(mainheading.textContent);

// mainheading.textContent="This is something else";

// console.log(mainheading.textContent);


// _____________________________________________________________________________________________________

// Inner text property   or INNERTEXT VS TEXTCONTENT
const mainheading = document.getElementById("main-heading");
// iise hum dekhenge ki manage your tasks k sath hello  print  nhi ho rha  h jaise wo textcontent
//  m ho rha tha   .. BASICALLY ISME WHI PRINT KRTA H JO WEBSITE PR DIKHTA H 
console.log(mainheading.innerText);
//isme hoga  hello print 
console.log(mainheading.textContent);

