// get and set attributes
// lets select firstanchor tag which is home
const link=document.querySelector("a");
console.log(link);
//we will get nothing using href attribute in get attribute becuse check html code href is blank (line 42 commented)
// in first anchor tag 
// console.log(link.getAttribute("href"));

// lets add some value of href there in html ab # home dikha rha h
console.log(link.getAttribute("href"));

// set attribute 
link.setAttribute("href","https://codprog.com");
//set krne k bad get kro or check kro kya show ho rha h.... phle #home tha ab change ho gya 
console.log(link.getAttribute("href"));


//Example-2
// _____________________________________________________________________________________
const inputelement=document.querySelector(".form-todo input");
console.log(inputelement)
console.log(inputelement.getAttribute("type"));
// ______________________________________________________________________________________________


