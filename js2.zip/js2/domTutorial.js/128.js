// index 8 and evt-bcd.css
// console.log("hello world");

// const grandparent= document.querySelector(".grandparent");
// const parent= document.querySelector(".parent");
// const child= document.querySelector(".child");
// const body=document.body;

//event bubbling

// child.addEventListener("click",()=>{
//     console.log("you clicked on child")
// })
// parent.addEventListener("click",()=>{
//     console.log("you clicked on parent")
// })
// grandparent.addEventListener("click",()=>{
//     console.log("you clicked on grandparent")
// })
// body.addEventListener("click",()=>{
//     console.log("you clicked on body");
// })

// check kro child pr click krne pr parent or child dono aa rhe h console  .....
// make sure ki phle upr ka sara code written ho without any comment  child and parent wala ...


// ab teesre wala grandparent bhi add kr lo ab check kro child pr click krne pr parent  grandparent 
// dono faltu m dikha rhe h 

// ab body add kro... bodyadd krne k baad parent , grandparent and body y teeno faltu m dikga rha h 

// ALL THESE ABOVE IS KNOWN AS EVENT BUBBLING / PROPAGATION
// ___________________________________________________________________________________________________
                                        //    FRESH START 


// console.log("hello world");

// const grandparent= document.querySelector(".grandparent");
// const parent= document.querySelector(".parent");
// const child= document.querySelector(".child");
// const body=document.body;


// CAPTURING EVENTS 
// child.addEventListener("click",()=>{
//     console.log("Capture !!! child")
// },true)
// parent.addEventListener("click",()=>{
//     console.log("Capture !!!parent")
// },true)
// grandparent.addEventListener("click",()=>{
//     console.log("Capture !!! grandparent")
// },true)
// body.addEventListener("click",()=>{
//     console.log("Capture !!! body");
// },true)



// not capture wale normal 
    // child.addEventListener("click",()=>{
    //     console.log("you clicked on child")
    // })
    // parent.addEventListener("click",()=>{
    //     console.log("you clicked on parent")
    // })
    // grandparent.addEventListener("click",()=>{
    //     console.log("you clicked on grandparent")
    // })
    // body.addEventListener("click",()=>{
    //     console.log("you clicked on body");
    // })


    // so inka output aise aaega phle sare capture wale aaenge .. outermost cpture s leke inner wale tk 
    // fir non capture wale aaenge inner wale s outermost tk 

    // no matter what the sequence is 
    // so in above output will be .. capture body , capture grandparent , capture  parent , capture child 
    // child, parent , grandparent , body 


    // yani phle capture krega fir bubling 



    // _________________________________________________________________________________________________
                                        //  FRESH START 


    //event deligation


// console.log("hello world");
// const grandparent= document.querySelector(".grandparent");
// grandparent.addEventListener("click",()=>{
//     console.log("you clicked something");
// })

// child pr click krne pr bhi show ho rha h you clicked something yani bubbling ho rha h wha 
// phle wo capturing wala dekhega jo nahi tha return jate waqt bubling wala mila islie  child pr click
// krne pr bhi grnadparent wala dikha rha h 
// Iska fayda y h ki hume alg alg event add krne ki zarurat nahi h sbke lie  evnt 
// fdelegation ho jaegi yha pr 



// ___________________________-

// console.log("hello world");
// const grandparent= document.querySelector(".grandparent");
// grandparent.addEventListener("click",(e)=>{
//     console.log(e);
// })

// upr wale m e.target add krne  m child k lie child ka milega parent k lie parent aise hi grandparent k lie 
// grand parent ka  .. check kro niche m 

console.log("hello world");
const grandparent= document.querySelector(".grandparent");
grandparent.addEventListener("click",(e)=>{
  
    console.log(e.target);
    // console.log(e.target.textContent);

})


// console agr e.target.textcontent krenge us case m 
// child ka child text aa rha h 
// parent ka (parent child) aa rha h  jo ki shi h kuki parent m child bhi h 
// grandparent ka (grandparent parent child aa rha h ) kuki grandparent m y sb text h 


// how can we stop this event delegation  simply check if e.target===grandparent 
// console.log("hello world");
// const grandparent= document.querySelector(".grandparent");
// grandparent.addEventListener("click",(e)=>{
//   if(e.target===grandparent){
//         console.log(e.target);
//   }

// })