// start again from indexed.html

const sectionTodo= document.querySelector(".section-todo")
console.log(sectionTodo);

// lets check how many classes have section todo 
console.log(sectionTodo.classList);

// ______________________________________________

// add a class through js .. first add in css  .bg-dark
// now add through here 

sectionTodo.classList.add("bg-dark")
// now check its added or not 
console.log(sectionTodo.classList);

// yes added 
// ______________________________________________________________

// remove a class through js 
sectionTodo.classList.remove("container");
console.log(sectionTodo.classList);
// yes removed 

// __________________________________________
// whether a class existts or not 

console.log(sectionTodo.classList.contains("container"));

// ____________________________________________
// TOGGLE opposite ans  kr deta h .. uske agla dobara check krenge to uska opposite  kr dega 
// like constainer class exist krti h but y false  kr dega 
// uske agli line m tobara toggle krenge to us bar exist nahi krti pr y true  kr dga 
// in short jo class h use hata dega .. jo nhi h use add kr dega 
// console.log(sectionTodo.classList.toggle("container"));
// console.log(sectionTodo.classList.toggle("container"));

// ___________________________________________________

// Lets work more on this topic 

// const header= document.querySelector(".header");
// console.log(header);
// header.classList.add("bg-dark");
// make sure that bg-dark is not overwritten .. i mean it must come after the header class properties 
// otherwise header class properties will change it .. becuase browser check css one by one 
// and last updated property ko wo assign krta h 
// check krke dekh skte h css file m .. agr hm bg-dark ko comment krke .. and copy krke
// agrheader class s upr like css m to effect nahi dikhega bg dark ka 