//index.html
// inner html to add html element

const todolist=document.querySelector(".todo-list");
console.log(todolist.innerHTML);
// this will change the old list but we want to add new 
todolist.innerHTML="<li>New Todo</li>";


//do like this  to add new element with inner html 
todolist.innerHTML+="<li>New Todo</li>";
todolist.innerHTML+="<li>Teach Students </li>";

// when you should use  inner html   and when you should not ..
// actually jb bhi hum new element add krte h to browser purance wla render krta h bar bar.
// to isse performance  issue ho jata h 

// kb use kro 
// jb hume inner html cahnge krna ho pura ka pura add nahi krna ho tb use kr skte h  inner html ko 


