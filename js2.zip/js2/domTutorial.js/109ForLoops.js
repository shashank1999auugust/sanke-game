// simple for loop
// for of loop
// for each method   Y HTML COLLECTION K SATH USE NAHI KR SKTE na getelement byclass k 
// sath na hi gtelembytag k sath 

// const navitems=document.getElementsByTagName("a");

let navitems=document.getElementsByTagName("a");  //html ccollection milega
console.log(navitems);

//simple for loop

// for(let i=0; i<navitems.length; i++){
//     // console.log(navitems[i]);
//     const navitem= navitems[i];
//     navitem.style.backgroundColor="#fff";
//     navitem.style.color="red";
//     navitem.style.fontWeight="bold";
// }


// for of loop

for(let navitem of navitems){
    navitem.style.backgroundColor="#fff";
        navitem.style.color="red";
        navitem.style.fontWeight="bold";
}


// we cant use for each 
// navitems.forEach((navitem)=>{
//     navitem.style.backgroundColor="#fff";
//     navitem.style.color="red";
//     navitem.style.fontWeight="bold";
// })


// we can covert html collection into array  and in start instead of const navitems  use let navitems
//  navitems=Array.from(navitems);
//  console.log (Array.isArray(navitems));
// we can now use for each  becuase now navitems is array not html collection 
// navitems.forEach((navitem)=>{
//     navitem.style.backgroundColor="#fff";
//     navitem.style.color="red";
//     navitem.style.fontWeight="bold";
// })
