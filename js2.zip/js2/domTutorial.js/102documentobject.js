// browser add document object in window object  lets check and print
console.log(window.document);


//javascript representataion of document object
console.dir(window.document);
//we can also write like this
console.dir(document);

