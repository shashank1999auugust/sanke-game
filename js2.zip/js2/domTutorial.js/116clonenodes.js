
//clone nodes
// const ul=  document.querySelector(".todo-list");
// const li= document.createElement("li");
// li.textContent="newwwwww todooooo";
// ul.append(li);
// // agr hume prepend bhi krna h to prepend to hoga pr append nhi rhega means jo LI h wo ek hi node h 
// ul.prepend(li);
// //2no ek sath nahi ho rhe .... 


// ________________________lets see how to cLone ___________________________________________________

// const ul=  document.querySelector(".todo-list");
// const li= document.createElement("li");
// li.textContent="newwwwww todooooo";
//aise clone krenge .. y true nahi likhenge to text content nahi aaega  //deep cloning hoti h taki child
//bhi aae li k (true likhne pr)
// const li2= li.cloneNode(true);
// ul.append(li);
// ul.prepend(li2);


// agr clone nahi krna to simpe new element create krke prepend kr do 
// const ul=document.querySelector(".todo-list")
// const li= document.createElement("li");
// li.textContent="newwwwww todooooo";
// const li2 = document.createElement("li");
// li2.textContent="createagain"
// ul.append(li)
// ul.prepend(li2)