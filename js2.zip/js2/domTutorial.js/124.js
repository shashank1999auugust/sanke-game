// index6.html
console.log("script start");
const allbuttons=document.querySelectorAll(".my-buttons button");
allbuttons.forEach((button)=>{
 button.addEventListener("click",(e)=>{
    let num=0;
    for(let i=0; i<=1000000000; i++){
        num+=i;
    }
    console.log(e.currentTarget.textContent,num);
 })
})
let outervar= 0;
for(let i=0;i<=100000000; i++){
outervar+=i;
}
console.log("value of outer value is ",outervar);
console.log("script end");

//format of printing 
//phle script start-> value of outer val-> script end  
// suppose humne ekdum s 3 no button pr click kr dia 
// fir bhi phle script start-> value of outer val-> script end   yhi print hogaa fir button wala content ,  
// kuki button wale content pr browser n web api rkhi thi or bola tha jb bhi user 
// click krega to iska callback function mko de dio . web api n de bhi dia callback dunction pr  callstack m phle s y 
// value of outer val-> script end  pda tha islie phle wo print hua or y 3 no button click wale ek callback queue m wait kr rhe the

// event loop ka kam hota h callstack m dekhna ki khali h ya nahi agr hali nahi hoga to wo in callback functions jo 
// button pr click hone s aae h inko aage nahi jane dega 