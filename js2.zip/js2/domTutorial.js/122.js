// Index6.html


// for one button 
//  const firstbutton=document.querySelector("#one");
//  firstbutton.addEventListener("click", function(){
//     console.log("you clicked me");
//  })
 

// how we can add this to all the three butoons 

// const allbuttons=document.querySelectorAll("button");
// console.log(allbuttons);

// for(let button of allbuttons){
//     button.addEventListener("click",function(){
//         console.log("you clicked me");
//     })
// }


// ______________________________________________

// const allbuttons=document.querySelectorAll("button");
// console.log(allbuttons);

// for(let button of allbuttons){
//     button.addEventListener("click",function(){
//         // console.log(this);
//         console.log(this.textContent);

//     })
// }
// everything seems working fine. dont use arrow funcrtion , as in earlier file 
// i mentioned that  arrow function's ka jo  this  hota h wo belong krta h  one level above 



// ______________________________________________________________

// lets do the same with different for loop 
// const allbuttons=document.querySelectorAll("button");

// for(let i=0; i<allbuttons.length; i++){
//     allbuttons[i].addEventListener("click",function(){
//                 console.log(this.textContent);
        
//             })
//         }


// ________________________________________-
// lets do the same with for eaCHAA LOOP 
const allbuttons=document.querySelectorAll("button");

allbuttons.forEach(function(button){
    button.addEventListener("click",function(){
                console.log(this); 
        })
        })
