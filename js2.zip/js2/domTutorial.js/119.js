
                                                //   use html3.js
//how to get the dimension of element

const sectiontodo =document.querySelector(".section-todo");
const info=sectiontodo.getBoundingClientRect();
// const info=sectiontodo.getBoundingClientRect().height;
// const info=sectiontodo.getBoundingClientRect().width;


console.log(info);

