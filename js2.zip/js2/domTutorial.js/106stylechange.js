//Change the styles of element
// before starting lets learn how we can target any element using query selector 
// div jiski class headline h usme s h2 elecmt select kro
// const mainheading=document.querySelector("div.headline h2");
// console.log(mainheading);



// task we need to change the color of manage your tasks  we can select like this also 

const mainheading= document.querySelector("#main-heading");
//style is object and we do have properties with style and so we can change colr and all other properties
console.log(mainheading.style);
mainheading.style.color="blue";
// upr wali line s color change ho jaega 
mainheading.style.border="5px solid red";
//upr wali line s border change ho jaega 
console.dir(mainheading.style)

// jis bhi properties m - aata h unhein kaise likhenge  ex- background-color 
// camel case m likhna pdta h jb bji - aega remove it and make first letter capital 
// like we removed - and make c to C in below example 
mainheading.style.backgroundColor  ="yellow";
