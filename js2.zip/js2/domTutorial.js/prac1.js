// ADD AND REMOVE CLASS WITH indexedDB.HTML
// const todo=document.querySelector(".section-todo")
// console.log(todo);
// console.log(todo.classList)
// todo.classList.add("bg-dark")
// console.log(todo.classList)
// todo.classList.remove("bg-dark")
// console.log(todo.classList)
// _______________________________________________________________________________________________________________


    let liElements=document.querySelectorAll('#mylist li')
    liElements.forEach(function(li){
        if(li.textContent==="odd"){
            li.classList.add("odd")
        }
        else if(li.textContent==="even"){
            li.classList.add("even")
        }
    })

// add this in index.html
{/* <ul id="mylist">
<li>odd</li>
<li>even</li>
<li>odd</li>
<li>even</li> 
// </ul> */}

// add this in style.css
// .odd{
//     background-color: red;
// }
// .even{
//     background-color: green;
// }