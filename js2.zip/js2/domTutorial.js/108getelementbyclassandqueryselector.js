//get multiple elements using getElement by class name
//get multiple element items using querySelectorAll

// lets select all a tag which have class nav items 
//class k through krenge to (html collections) milega y bhi array like object h 
const navitems=document.getElementsByClassName("nav-item");
console.log(navitems);
console.log(navitems[1]);
console.log (Array.isArray(navitems));



//iske through krenge to (nodelist milega) 
const navitem= document.querySelectorAll(".nav-item");
console.log(navitem);
console.log (Array.isArray(navitems));
console.log(navitem[2]);
