//INNER HTML
// for example header html file m header wale k bich m jo bhi h wo sari uski inner html h 
const headline = document.querySelector(".headline");
// print and see what we get  we will get headline class ki andar ki inner html.. 
console.log(headline)
// find headline class in html code 
console.log(headline.innerHTML)

// check changes in inner html on website 
headline.innerHTML="<h1>Inner html changed</h1>";

// button add klia or usme ek class bhi de di 
//  " " iske andr " " y use nahin kr skte  dobara islie  niche line m \" \" 
// use kia h 2nd wale " " iske time 
headline.innerHTML += "<button class=\"btn\">Learn More </button>";