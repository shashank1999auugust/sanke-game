//select element using get element by id
console.log(document.getElementById("main-heading"));


// actual m y mil rha h (object) which is object upr wala just readable format k lie h 
console.dir(document.getElementById("main-heading"));
// document object k andr multiple objects hote h aise har html ement k alg 

// check its type 
console.log( typeof document.getElementById("main-heading"));
