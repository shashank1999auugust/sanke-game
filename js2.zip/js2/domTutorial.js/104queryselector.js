//select element using query selector
//here main id heading is id so use #
const mainheading=document.querySelector("#main-heading");
console.log(mainheading);

// using query selector we can select anythig
// lets select header class 
const header=document.querySelector(".header");
console.log(header);

//rule in html file dont give same id to multiple elements bt we can give same calss to multiple elements
//niche check kro nav-item classs 3 list ko di hui h pr output m ek hi aaega first wala
const navitem=document.querySelector(".nav-item");
// console.log(navitem);

// if we want all items jinki class nav-item h then use this 
const navitems=document.querySelectorAll(".nav-item");
console.log(navitems);
// we will get all in the form of nodelist which is like array but not array s