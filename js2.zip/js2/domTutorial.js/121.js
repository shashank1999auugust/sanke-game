// INDEX5.HTM

//THIS KEYWORD          ...click on learn more and checkin colsole
const btn=document.querySelector(".btn-headline");

// btn.addEventListener("click", function(){ 
//         console.log("you clicked me ");
//         console.log("value of this");
//         console.log(this);
//     });

    // this ki value yhi  button hogi normal function m 


    // _________________________________________________

    // lets chck for arrow function 

    btn.addEventListener("click", ()=>{ 
        console.log("you clicked me ");
        console.log("value of this");
        console.log(this);
    });

    // is arrow cASE ME window hoga kuki arrow function  ka this  1 level up hota h 
    // .. click on lear more and check in console