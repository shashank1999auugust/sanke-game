
//                        //MUST GO THROUGH 111.PNG BEFORE THIS 
//                                    ++
//                               USE INDEX2.HTML


// const rootnode=document.getRootNode();
// // verify that document is the root nodd 
// console.log(rootnode);

// // LETS CHECK THE CHILD OF ROOT NODES  it will give a node list we can check html is there 
// console.log(rootnode.childNodes);
// // node list is  array like so we can access by index  .. we can see html is coming 
// console.log(rootnode.childNodes[0]);

// __________________________________________________________________________________
// do from here fresh again comment all above 
// const rootNode=document.getRootNode();
// const htmlElementNode=rootNode.childNodes[0];
// console.log(htmlElementNode);
// htmlelementnode k childnodes 
// console.log(htmlElementNode.childNodes);  // a LIST COME WHICH WILL CONTAIN  head, text , body h 

// lets print them seperately   
// const headElementNode=htmlElementNode.childNodes[0];
// console.log(headElementNode);
// const textnode1=htmlElementNode.childNodes[1];
// console.log(textnode1);
// const bodyelementnode= htmlElementNode.childNodes[2];
// console.log(bodyelementnode)


// headElementNode ka parent aa rha h html 
// console.log(headElementNode.parentNode)


//sibling relation ...... head ka sibling text h kuki 2ndo k parent same h 
// aap soch rhe hongr=e html code m koi text to dikh nahi rha actually m head and body kl bich ka space 
// and /n jo hota h wo as a text count hota h  
// y jo niche wali lie print ho rhi h ise open krke iska data check kro console m 
// iska data /n and space aaega 
// console.log(headElementNode.nextSibling); //textnode
// sibling ka sibing kon h ( yani text ka sibling kon h body h )
// console.log(headElementNode.nextSibling.nextSibling);  //body


//this will not give text sibling  it ignores text /........it will give element sibling  (body)
// console.log(headElementNode.nextElementSibling);


// console.log(headElementNode.childNodes);


// _____________________________________________________________________________________
//DOM TRAVERSING

// const h1=document.querySelector("h1");
// const div=h1.parentNode;
// div.style.color="efefef"
// div.style.backgroundColor="#333"
// const body=h1.parentNode.parentNode
// body.style.coolor="efefef"
// body.style.backgroundColor="#333"


//we can select body like this also 
// const body= document.body;
// console.log(body);
// body.style.coolor="efefef"
// body.style.backgroundColor="#333"

// const head= document.querySelector("head");
// console.log(head);
//queryselector to target childs of head
// const title= head.querySelector("title");
// console.log(title.childNodes);



// IN OUTPUT WE DONT NEED THAT SPACE AND NEW LINE WHICH IS TEXT OUTPUT WE NEED WHICH REALY EXIST IN HTML
const container =document.querySelector(".container")
//ISSE TEXT WALE BHI DIKHAEGA  5 aaenge total diagram m galti h 111.png  ek text or aaega jo paragraph
// k bad h 
console.log(container.childNodes);
//ISSE NAHI DIKHAEGA text wale h1 and p aaega only 
console.log(container.children)