// index 6 
// little practice with click events
const allbuttons= document.querySelectorAll(".my-buttons button");
console.log(allbuttons.length);
allbuttons.forEach(button=>{
    button.addEventListener("click", (e)=>{
        // console.log(e.target);
        e.target.style.backgroundColor="yellow";
    })
})


// using for of 
// for(let button of allbuttons){
//     button.addEventListener("click",(e)=>{
//         console.log(e.target);
//         e.target.style.backgroundColor="yellow";
//     })
// }