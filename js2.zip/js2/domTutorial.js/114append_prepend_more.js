// so how to add new element 
//append, prepend, remove,before,after

// const newtodoitem=document.createElement("li")
// const newtodoitemtext=document.createTextNode(" teach students")
// const todolist=document.querySelector(".todo-list");

// newtodoitem.append(newtodoitemtext);
// todolist.append(newtodoitem);
// console.log(newtodoitem);


// ______________________________________________________________________________________________
// or we can write like this  shortcut
// how to add new element 
// const newtodoitem=document.createElement("li")
// newtodoitem.textContent="Teach students"
// const todolist=document.querySelector(".todo-list");
//  to add after 
// todolist.append(newtodoitem);

// to add before 
// todolist.prepend(newtodoitem);

// console.log(newtodoitem);


// ______________________________________________________________
// how to remove html element  todo1        (REMOVES FROM TOP)
// const todo1=document.querySelector(".todo-list li");
// todo1.remove();
// console.log(todo1);

// _________________________________________________________
// agr hume ul s phle hi insert krna h ya uske bad to (ul todo-list s phle ya uske ed hone k bad)
// append and prepend iske andr k lie tha 




const newtodoitem=document.createElement("li");
newtodoitem.textContent="teach students";
const todolist=document.querySelector(".todo-list");
todolist.before(newtodoitem);
todolist.after(newtodoitem);
