console.log("hello word");
let firstname= "harshisht";
let lastname= "vashisht";

const myfunction=function(){
    let var1="variable1";
    let var2="variable2";
    console.log(var1);
    console.log(var2);
}

                                // Compilation phase 

// 1st early error checking ------ No error in syntax 
// 2nd check scope of variable                      GLOBAL SCOPE 
                                                    // firstname
                                                    // lastname

                                                    // myfunction  ----> contain 2 variable var1, var2

// __________________________________________________________________________________________________

    // javascript also known as lexical scope langauge 

// compilation phases         1) tokenizing/lexing  - code breaks into small pieces known as tokens
                            //   2)Parsing  - AST create (abstract syntax tree create after check small tokens )
                            //   3)code generation- with the help of AST ek exutable format m code  generate hota h 
 