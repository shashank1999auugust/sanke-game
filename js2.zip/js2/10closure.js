
function myfunction(power){  //1
    return function(number){      //myfunc1
       return number **power;        
    }
}
const square=myfunction(2); //2
 const ans=square(3); //3
 console.log(ans); //4

   //  global execution context

// -----------------------------------------------------------------------------------------------------

//  CODE EXECTUTION PHASE                     |                      GLOBAL MEMORY / CREATION PHASE
//                                            |
//                                            |                         window:{}
//                                            |                         this:window{}
//                                                                      myfunction{}
//                                                                    square:uninitialized
//                                                                    ans:uninitialized

// global execution 
// 1) kuch nahi hoga
// 2nd line m myfuction ko call krenge to function execution context create hoga myfunction k lie 

// myfunction execution s return aane k baad ab jo function wha s return hua h wo  square m save 
//ho jaega  sath m wo apne power bhi leke aaya h 
// 3) line execute  hone pr  square ko call kro ab fir s function execution context create hoga 
//square k lie 

// sqare execution context s return aane k bad 
// wha s wo 9 return krega jo ans m store ho jaegi
// 4) print ans which is 9 

                       // myfunction execution context 
// -----------------------------------------------------------------------------------------------------

//  CODE EXECTUTION PHASE                     |                      local MEMORY / CREATION PHASE
//                                            |                
                                                                    //   arguments[2]
                                                                    //   power:2
                                                                    //   function{} 

// execution of myfunction 

//myfunc1 --execute hogi to  return hoga function ab y function return hoga to khali hath return 
//nahi hoga apne sath power ko leke return hoga
// yha pr myfuction execution khtm waps global execution pr jao 


// ___________________________________________________________________________________________

                    // square execution context 
            //   ans k pas jo h =    return function(number){      
            //                         return number **power;        //1 
            //                           }
            // + power bhi h jo closure s laya h 
// -----------------------------------------------------------------------------------------------------

//  CODE EXECTUTION PHASE                     |                      local MEMORY / CREATION PHASE
//                                            |                
                                                             //  arguments[]
                                                            // number:3
//execution jb 1 chlegi return number **power;     number h humare pas plus power y leke aayah h 
// to ans =9 ho jaega 
// waps s global execution pr jao        
