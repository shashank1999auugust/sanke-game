// VAR + FUNTION DECLARATION K CASE M 


// Y JO BHI HO RHA H ISE HOISTING KHTE H , lIKE UNDEFINED SET HONA VAR KA CREATION PHASE 
// M ISLIE OUTPUT M UNDEFINED AANA AGR HUM USSE PHLE ACESS KRENGE USE TO 
console.log(this);             //1stline
console.log(window);           //2
console.log(myfunction);       //3
console.log(fullname);         //4
//function declaration
myfunction(); // we can call myfunction before declaration in case of function declaration 
function myfunction(){                      //5
 console.log("this is my function");        
}
var firstname="harshit";                    //6
var lastname= "sharma";                     //7
var fullname=firstname+" " +lastname;       //8
console.log(fullname);                      //9

// in above code lets che k first whill all are uncdr global scope 
                                   //GLOBAL SCOPE
// ________________________________________________________________________________________________________
// firstname, lastname , fullname, myfunction 

     
                                  // GLOBAL EXECUTION CONTEXT 
// -----------------------------------------------------------------------------------------------------

//  CODE EXECTUTION PHASE                      |                      GLOBAL MEMORY / CREATION PHASE
//                                             |
//                                             |                       WINDOW:{}
//                                             |                      THIS: WINDOW{}
//                                             |                      firstname : undefined
//                                             |                       lastname  :undefined
//                                             |                       fullname : undefined
//                                             |                       myfunction pura 


                                      // console 
// ______________________________________________________________________________________________________
//1stline                             window{}
// 2ndline                            window{}
//3rdline                              function myfunction(){
                                        // console.log("this is my function");
                                           //}


// 4th line                        undefined 
//5th line                        (5th line s kuch nahi hoga )
//6th line                          (global memory m first name ki value ko harshit kr do )
// 7th line                         (lastname="sharma")
// 8th line                        (it will set value for fullname= harshit sharma)
// 9th line                         harshit sharma