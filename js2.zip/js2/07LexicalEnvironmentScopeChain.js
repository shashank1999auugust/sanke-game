// lexical environment , scope chain
const lastname ="vashishta"; //1

const printname=function(){  //2
    const firstname="harshit";  //f1
    console.log(firstname);    //f2
    console.log(lastname);      //f3
}

printname();//3
                        //  global execution context

// -----------------------------------------------------------------------------------------------------

//  CODE EXECTUTION PHASE                     |                      GLOBAL MEMORY / CREATION PHASE
//                                            |
//                                            |                         window:{}
//                                            |                         this:window{}
//                                                                     lastname:uninitialized
//                                                                   printname: unitialised

                // global execution 
// 1st) lastname unititalised s change hoke vashishta ho jaega
// 2nd)  printname unitialised nahi rhegi ab function bn jaegi 
// 3rd ) printname ko call kro .. jaise hi call krenge new execution ontext aa jaega 
// which is function exection context 



                       // function execution context 
// -------------------------------------------------------------------------------------------------

//  CODE EXECTUTION PHASE                     |                      function MEMORY / CREATION PHASE
                                                                    //   arguments :[....]
                                                                    // firstname: unitialised

// function execution 
// f1) firstname unititalised s harshit ho jaega 
// f2) harshit
// f3) last name print krne ko kh rhi h f3  but function memory k pas to last name h hi nahi 
// if javascript not able to find in localmemory then it checks in parent class means it will check in 
// the  memory of global execution context (global memory ) lexically check krte jaega jb tk
//  global tk na phuch jae 
// so it will print vashishta 







// _______________________________________________________________________________________________

// const lastname ="vashishta"; 
// const printname=function(){ 
//     const firstname="harshit"; 
//     function myfunction(){
//     console.log(firstname);    
//     console.log(lastname); 
//     } 
//      myfunction();
// }
// printname();

// isme kya hoga y dekhega ki myfunction k pas to na  fitstname h na lastname to y apne
//  lexical printname m check krega  wha s isko firstname mil jaega but last name abhi bhi nahi Mila 
//  to fir y ab iske lexical m yani global m dekhega wha pr lastname h to print kr dega 
// jb tk global execution tk nahi phuchta tb tk dekhte rhta h 